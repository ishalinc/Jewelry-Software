﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IshalInc.wJewel.Data.DataModel
{
    public class BankAcc
    {
        public string CODE { get; set; }

        public string DESC { get; set; }

        public string LAST_INV { get; set; }

        public bool? IS_QB { get; set; }

        public string QB_NAME { get; set; }

    }


}
