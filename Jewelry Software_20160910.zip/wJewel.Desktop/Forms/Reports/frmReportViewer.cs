﻿using System;

using System.Windows.Forms;
using System.IO;

namespace IshalInc.wJewel.Desktop.Forms
{
    public partial class frmReportViewer : Form 
    {
        public frmReportViewer()
        {
            InitializeComponent();
        }

        private void frmReportViewer_Load(object sender, EventArgs e)
        {

        }
    }
}
