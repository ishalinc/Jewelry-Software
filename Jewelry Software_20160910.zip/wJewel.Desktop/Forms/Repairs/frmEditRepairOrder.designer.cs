﻿namespace IshalInc.wJewel.Desktop.Forms
{
    partial class frmEditRepairOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            this.radGridView1 = new Telerik.WinControls.UI.RadGridView();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.repairordernote = new Telerik.WinControls.UI.RadTextBoxControl();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.ordercreditrepair = new Telerik.WinControls.UI.RadCheckBox();
            this.radGroupBox4 = new Telerik.WinControls.UI.RadGroupBox();
            this.orderresidential = new Telerik.WinControls.UI.RadCheckBox();
            this.radGroupBox7 = new Telerik.WinControls.UI.RadGroupBox();
            this.shipbyupsserver = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbyregular = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbyearlyam = new Telerik.WinControls.UI.RadRadioButton();
            this.radGroupBox6 = new Telerik.WinControls.UI.RadGroupBox();
            this.shipbyground = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbysaturday = new Telerik.WinControls.UI.RadRadioButton();
            this.shipby3day = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbyaaa = new Telerik.WinControls.UI.RadRadioButton();
            this.shipby2day = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbynone = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbymail = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbynextday = new Telerik.WinControls.UI.RadRadioButton();
            this.shipby2dayletter = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbypickup = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbyredletter = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbydelivery = new Telerik.WinControls.UI.RadRadioButton();
            this.radGroupBox5 = new Telerik.WinControls.UI.RadGroupBox();
            this.shipbycodcheck = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbycodcash = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbynoncode = new Telerik.WinControls.UI.RadRadioButton();
            this.radLabel10 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox3 = new Telerik.WinControls.UI.RadGroupBox();
            this.ordercanceldate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.orderentrydate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.orderrecivedate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.customerdebitmemonumber = new Telerik.WinControls.UI.RadTextBox();
            this.customerrepairorderno = new Telerik.WinControls.UI.RadTextBox();
            this.orderrepairno = new Telerik.WinControls.UI.RadTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            this.ordercountry = new Telerik.WinControls.UI.RadTextBox();
            this.orderzip = new Telerik.WinControls.UI.RadTextBox();
            this.orderstate = new Telerik.WinControls.UI.RadTextBox();
            this.ordercity = new Telerik.WinControls.UI.RadTextBox();
            this.orderadd2 = new Telerik.WinControls.UI.RadTextBox();
            this.orderadd1 = new Telerik.WinControls.UI.RadTextBox();
            this.ordshipto = new Telerik.WinControls.UI.RadTextBox();
            this.ordcustcode = new Telerik.WinControls.UI.RadTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.totalqty = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairordernote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordercreditrepair)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).BeginInit();
            this.radGroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderresidential)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox7)).BeginInit();
            this.radGroupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyupsserver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyregular)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyearlyam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox6)).BeginInit();
            this.radGroupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbysaturday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipby3day)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyaaa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipby2day)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbynone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbymail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbynextday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipby2dayletter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbypickup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyredletter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbydelivery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox5)).BeginInit();
            this.radGroupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shipbycodcheck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbycodcash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbynoncode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).BeginInit();
            this.radGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ordercanceldate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderentrydate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderrecivedate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerdebitmemonumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerrepairorderno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderrepairno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ordercountry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderstate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordercity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderadd2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderadd1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordshipto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordcustcode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalqty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radGridView1
            // 
            this.radGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.radGridView1.Location = new System.Drawing.Point(11, 205);
            // 
            // 
            // 
            this.radGridView1.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.radGridView1.Name = "radGridView1";
            this.radGridView1.Size = new System.Drawing.Size(523, 280);
            this.radGridView1.TabIndex = 75;
            this.radGridView1.TabStop = false;
            this.radGridView1.Text = "radGridView1";
            this.radGridView1.CellValidated += new Telerik.WinControls.UI.CellValidatedEventHandler(this.radGridView1_CellValidated);
            this.radGridView1.CellValueChanged += new Telerik.WinControls.UI.GridViewCellEventHandler(this.radGridView1_CellValueChanged);
            // 
            // radButton2
            // 
            this.radButton2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.radButton2.Image = global::IshalInc.wJewel.Desktop.Properties.Resources.cancel;
            this.radButton2.Location = new System.Drawing.Point(395, 578);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(68, 24);
            this.radButton2.TabIndex = 74;
            this.radButton2.Text = "Cancel";
            this.radButton2.Click += new System.EventHandler(this.radButton2_Click);
            // 
            // radButton1
            // 
            this.radButton1.Image = global::IshalInc.wJewel.Desktop.Properties.Resources.OK;
            this.radButton1.Location = new System.Drawing.Point(311, 578);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(66, 24);
            this.radButton1.TabIndex = 73;
            this.radButton1.Text = "OK";
            this.radButton1.Click += new System.EventHandler(this.radButton1_Click);
            // 
            // repairordernote
            // 
            this.repairordernote.Location = new System.Drawing.Point(61, 511);
            this.repairordernote.Name = "repairordernote";
            this.repairordernote.Size = new System.Drawing.Size(675, 61);
            this.repairordernote.TabIndex = 72;
            // 
            // radLabel3
            // 
            this.radLabel3.Location = new System.Drawing.Point(11, 511);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(31, 18);
            this.radLabel3.TabIndex = 69;
            this.radLabel3.Text = "Note";
            // 
            // ordercreditrepair
            // 
            this.ordercreditrepair.Location = new System.Drawing.Point(377, 491);
            this.ordercreditrepair.Name = "ordercreditrepair";
            this.ordercreditrepair.Size = new System.Drawing.Size(163, 18);
            this.ordercreditrepair.TabIndex = 71;
            this.ordercreditrepair.Text = "Issue Credit For Repair Items";
            // 
            // radGroupBox4
            // 
            this.radGroupBox4.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(240)))), ((int)(((byte)(249)))));
            this.radGroupBox4.Controls.Add(this.orderresidential);
            this.radGroupBox4.Controls.Add(this.radGroupBox7);
            this.radGroupBox4.Controls.Add(this.radGroupBox6);
            this.radGroupBox4.Controls.Add(this.radGroupBox5);
            this.radGroupBox4.HeaderText = "";
            this.radGroupBox4.Location = new System.Drawing.Point(547, 223);
            this.radGroupBox4.Name = "radGroupBox4";
            this.radGroupBox4.Size = new System.Drawing.Size(187, 286);
            this.radGroupBox4.TabIndex = 70;
            // 
            // orderresidential
            // 
            this.orderresidential.Location = new System.Drawing.Point(5, 265);
            this.orderresidential.Name = "orderresidential";
            this.orderresidential.Size = new System.Drawing.Size(75, 18);
            this.orderresidential.TabIndex = 60;
            this.orderresidential.Text = "Residential";
            // 
            // radGroupBox7
            // 
            this.radGroupBox7.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox7.Controls.Add(this.shipbyupsserver);
            this.radGroupBox7.Controls.Add(this.shipbyregular);
            this.radGroupBox7.Controls.Add(this.shipbyearlyam);
            this.radGroupBox7.HeaderText = "";
            this.radGroupBox7.Location = new System.Drawing.Point(5, 214);
            this.radGroupBox7.Name = "radGroupBox7";
            this.radGroupBox7.Size = new System.Drawing.Size(176, 48);
            this.radGroupBox7.TabIndex = 2;
            // 
            // shipbyupsserver
            // 
            this.shipbyupsserver.Location = new System.Drawing.Point(5, 25);
            this.shipbyupsserver.Name = "shipbyupsserver";
            this.shipbyupsserver.Size = new System.Drawing.Size(74, 18);
            this.shipbyupsserver.TabIndex = 32;
            this.shipbyupsserver.TabStop = false;
            this.shipbyupsserver.Text = "Ups Server";
            // 
            // shipbyregular
            // 
            this.shipbyregular.CheckState = System.Windows.Forms.CheckState.Checked;
            this.shipbyregular.Location = new System.Drawing.Point(5, 6);
            this.shipbyregular.Name = "shipbyregular";
            this.shipbyregular.Size = new System.Drawing.Size(58, 18);
            this.shipbyregular.TabIndex = 30;
            this.shipbyregular.TabStop = false;
            this.shipbyregular.Text = "Regular";
            this.shipbyregular.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            // 
            // shipbyearlyam
            // 
            this.shipbyearlyam.Location = new System.Drawing.Point(95, 6);
            this.shipbyearlyam.Name = "shipbyearlyam";
            this.shipbyearlyam.Size = new System.Drawing.Size(64, 18);
            this.shipbyearlyam.TabIndex = 31;
            this.shipbyearlyam.TabStop = false;
            this.shipbyearlyam.Text = "Early Am";
            // 
            // radGroupBox6
            // 
            this.radGroupBox6.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(240)))), ((int)(((byte)(249)))));
            this.radGroupBox6.Controls.Add(this.shipbyground);
            this.radGroupBox6.Controls.Add(this.shipbysaturday);
            this.radGroupBox6.Controls.Add(this.shipby3day);
            this.radGroupBox6.Controls.Add(this.shipbyaaa);
            this.radGroupBox6.Controls.Add(this.shipby2day);
            this.radGroupBox6.Controls.Add(this.shipbynone);
            this.radGroupBox6.Controls.Add(this.shipbymail);
            this.radGroupBox6.Controls.Add(this.shipbynextday);
            this.radGroupBox6.Controls.Add(this.shipby2dayletter);
            this.radGroupBox6.Controls.Add(this.shipbypickup);
            this.radGroupBox6.Controls.Add(this.shipbyredletter);
            this.radGroupBox6.Controls.Add(this.shipbydelivery);
            this.radGroupBox6.HeaderText = "";
            this.radGroupBox6.Location = new System.Drawing.Point(5, 70);
            this.radGroupBox6.Name = "radGroupBox6";
            this.radGroupBox6.Size = new System.Drawing.Size(176, 141);
            this.radGroupBox6.TabIndex = 2;
            // 
            // shipbyground
            // 
            this.shipbyground.Location = new System.Drawing.Point(5, 9);
            this.shipbyground.Name = "shipbyground";
            this.shipbyground.Size = new System.Drawing.Size(58, 18);
            this.shipbyground.TabIndex = 18;
            this.shipbyground.TabStop = false;
            this.shipbyground.Text = "Ground";
            // 
            // shipbysaturday
            // 
            this.shipbysaturday.Location = new System.Drawing.Point(95, 9);
            this.shipbysaturday.Name = "shipbysaturday";
            this.shipbysaturday.Size = new System.Drawing.Size(64, 18);
            this.shipbysaturday.TabIndex = 24;
            this.shipbysaturday.TabStop = false;
            this.shipbysaturday.Text = "Saturday";
            // 
            // shipby3day
            // 
            this.shipby3day.Location = new System.Drawing.Point(5, 31);
            this.shipby3day.Name = "shipby3day";
            this.shipby3day.Size = new System.Drawing.Size(50, 18);
            this.shipby3day.TabIndex = 19;
            this.shipby3day.TabStop = false;
            this.shipby3day.Text = "3-Day";
            // 
            // shipbyaaa
            // 
            this.shipbyaaa.Location = new System.Drawing.Point(95, 31);
            this.shipbyaaa.Name = "shipbyaaa";
            this.shipbyaaa.Size = new System.Drawing.Size(42, 18);
            this.shipbyaaa.TabIndex = 25;
            this.shipbyaaa.TabStop = false;
            this.shipbyaaa.Text = "AAA";
            // 
            // shipby2day
            // 
            this.shipby2day.Location = new System.Drawing.Point(5, 52);
            this.shipby2day.Name = "shipby2day";
            this.shipby2day.Size = new System.Drawing.Size(50, 18);
            this.shipby2day.TabIndex = 20;
            this.shipby2day.TabStop = false;
            this.shipby2day.Text = "2-Day";
            // 
            // shipbynone
            // 
            this.shipbynone.CheckState = System.Windows.Forms.CheckState.Checked;
            this.shipbynone.Location = new System.Drawing.Point(95, 117);
            this.shipbynone.Name = "shipbynone";
            this.shipbynone.Size = new System.Drawing.Size(48, 18);
            this.shipbynone.TabIndex = 29;
            this.shipbynone.TabStop = false;
            this.shipbynone.Text = "None";
            this.shipbynone.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            // 
            // shipbymail
            // 
            this.shipbymail.Location = new System.Drawing.Point(95, 52);
            this.shipbymail.Name = "shipbymail";
            this.shipbymail.Size = new System.Drawing.Size(42, 18);
            this.shipbymail.TabIndex = 26;
            this.shipbymail.TabStop = false;
            this.shipbymail.Text = "Mail";
            // 
            // shipbynextday
            // 
            this.shipbynextday.Location = new System.Drawing.Point(5, 74);
            this.shipbynextday.Name = "shipbynextday";
            this.shipbynextday.Size = new System.Drawing.Size(66, 18);
            this.shipbynextday.TabIndex = 21;
            this.shipbynextday.TabStop = false;
            this.shipbynextday.Text = "Next Day";
            // 
            // shipby2dayletter
            // 
            this.shipby2dayletter.Location = new System.Drawing.Point(5, 117);
            this.shipby2dayletter.Name = "shipby2dayletter";
            this.shipby2dayletter.Size = new System.Drawing.Size(76, 18);
            this.shipby2dayletter.TabIndex = 23;
            this.shipby2dayletter.TabStop = false;
            this.shipby2dayletter.Text = "2day Letter";
            // 
            // shipbypickup
            // 
            this.shipbypickup.Location = new System.Drawing.Point(95, 74);
            this.shipbypickup.Name = "shipbypickup";
            this.shipbypickup.Size = new System.Drawing.Size(53, 18);
            this.shipbypickup.TabIndex = 27;
            this.shipbypickup.TabStop = false;
            this.shipbypickup.Text = "Pickup";
            // 
            // shipbyredletter
            // 
            this.shipbyredletter.Location = new System.Drawing.Point(5, 95);
            this.shipbyredletter.Name = "shipbyredletter";
            this.shipbyredletter.Size = new System.Drawing.Size(71, 18);
            this.shipbyredletter.TabIndex = 22;
            this.shipbyredletter.TabStop = false;
            this.shipbyredletter.Text = "Red Letter";
            // 
            // shipbydelivery
            // 
            this.shipbydelivery.Location = new System.Drawing.Point(95, 95);
            this.shipbydelivery.Name = "shipbydelivery";
            this.shipbydelivery.Size = new System.Drawing.Size(60, 18);
            this.shipbydelivery.TabIndex = 28;
            this.shipbydelivery.TabStop = false;
            this.shipbydelivery.Text = "Delivery";
            // 
            // radGroupBox5
            // 
            this.radGroupBox5.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox5.Controls.Add(this.shipbycodcheck);
            this.radGroupBox5.Controls.Add(this.shipbycodcash);
            this.radGroupBox5.Controls.Add(this.shipbynoncode);
            this.radGroupBox5.HeaderText = "";
            this.radGroupBox5.Location = new System.Drawing.Point(5, 6);
            this.radGroupBox5.Name = "radGroupBox5";
            this.radGroupBox5.Size = new System.Drawing.Size(176, 60);
            this.radGroupBox5.TabIndex = 16;
            // 
            // shipbycodcheck
            // 
            this.shipbycodcheck.Location = new System.Drawing.Point(8, 39);
            this.shipbycodcheck.Name = "shipbycodcheck";
            this.shipbycodcheck.Size = new System.Drawing.Size(73, 18);
            this.shipbycodcheck.TabIndex = 21;
            this.shipbycodcheck.TabStop = false;
            this.shipbycodcheck.Text = "Cod-check";
            // 
            // shipbycodcash
            // 
            this.shipbycodcash.Location = new System.Drawing.Point(8, 21);
            this.shipbycodcash.Name = "shipbycodcash";
            this.shipbycodcash.Size = new System.Drawing.Size(67, 18);
            this.shipbycodcash.TabIndex = 20;
            this.shipbycodcash.TabStop = false;
            this.shipbycodcash.Text = "Cod-cash";
            // 
            // shipbynoncode
            // 
            this.shipbynoncode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.shipbynoncode.Location = new System.Drawing.Point(8, 2);
            this.shipbynoncode.Name = "shipbynoncode";
            this.shipbynoncode.Size = new System.Drawing.Size(65, 18);
            this.shipbynoncode.TabIndex = 19;
            this.shipbynoncode.TabStop = false;
            this.shipbynoncode.Text = "Non-cod";
            this.shipbynoncode.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            // 
            // radLabel10
            // 
            this.radLabel10.AutoSize = false;
            this.radLabel10.BackColor = System.Drawing.Color.RoyalBlue;
            this.radLabel10.BorderVisible = true;
            this.radLabel10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel10.ForeColor = System.Drawing.Color.White;
            this.radLabel10.Location = new System.Drawing.Point(12, 12);
            this.radLabel10.Name = "radLabel10";
            this.radLabel10.Size = new System.Drawing.Size(335, 18);
            this.radLabel10.TabIndex = 64;
            this.radLabel10.Text = "Customer Details";
            this.radLabel10.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radLabel1
            // 
            this.radLabel1.AutoSize = false;
            this.radLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.radLabel1.BorderVisible = true;
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel1.ForeColor = System.Drawing.Color.White;
            this.radLabel1.Location = new System.Drawing.Point(381, 12);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(355, 18);
            this.radLabel1.TabIndex = 65;
            this.radLabel1.Text = "Repair Order Details";
            this.radLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radLabel2
            // 
            this.radLabel2.AutoSize = false;
            this.radLabel2.BackColor = System.Drawing.Color.Crimson;
            this.radLabel2.BorderVisible = true;
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel2.ForeColor = System.Drawing.Color.White;
            this.radLabel2.Location = new System.Drawing.Point(547, 205);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(187, 18);
            this.radLabel2.TabIndex = 68;
            this.radLabel2.Text = "Shipping Methods";
            this.radLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radGroupBox3
            // 
            this.radGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox3.Controls.Add(this.ordercanceldate);
            this.radGroupBox3.Controls.Add(this.orderentrydate);
            this.radGroupBox3.Controls.Add(this.orderrecivedate);
            this.radGroupBox3.Controls.Add(this.customerdebitmemonumber);
            this.radGroupBox3.Controls.Add(this.customerrepairorderno);
            this.radGroupBox3.Controls.Add(this.orderrepairno);
            this.radGroupBox3.Controls.Add(this.label12);
            this.radGroupBox3.Controls.Add(this.label11);
            this.radGroupBox3.Controls.Add(this.label10);
            this.radGroupBox3.Controls.Add(this.label9);
            this.radGroupBox3.Controls.Add(this.label8);
            this.radGroupBox3.Controls.Add(this.label7);
            this.radGroupBox3.HeaderText = "";
            this.radGroupBox3.Location = new System.Drawing.Point(381, 24);
            this.radGroupBox3.Name = "radGroupBox3";
            this.radGroupBox3.Size = new System.Drawing.Size(355, 175);
            this.radGroupBox3.TabIndex = 66;
            // 
            // ordercanceldate
            // 
            this.ordercanceldate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ordercanceldate.Location = new System.Drawing.Point(168, 81);
            this.ordercanceldate.Name = "ordercanceldate";
            this.ordercanceldate.Size = new System.Drawing.Size(160, 20);
            this.ordercanceldate.TabIndex = 12;
            this.ordercanceldate.TabStop = false;
            this.ordercanceldate.Text = "6/10/2016";
            this.ordercanceldate.ThemeName = "TelerikMetroBlue";
            this.ordercanceldate.Value = new System.DateTime(2016, 6, 10, 0, 0, 0, 0);
            // 
            // orderentrydate
            // 
            this.orderentrydate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.orderentrydate.Location = new System.Drawing.Point(168, 56);
            this.orderentrydate.Name = "orderentrydate";
            this.orderentrydate.Size = new System.Drawing.Size(160, 20);
            this.orderentrydate.TabIndex = 11;
            this.orderentrydate.TabStop = false;
            this.orderentrydate.Text = "6/9/2016";
            this.orderentrydate.ThemeName = "TelerikMetroBlue";
            this.orderentrydate.Value = new System.DateTime(2016, 6, 9, 14, 54, 33, 0);
            // 
            // orderrecivedate
            // 
            this.orderrecivedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.orderrecivedate.Location = new System.Drawing.Point(168, 33);
            this.orderrecivedate.Name = "orderrecivedate";
            this.orderrecivedate.Size = new System.Drawing.Size(159, 20);
            this.orderrecivedate.TabIndex = 10;
            this.orderrecivedate.TabStop = false;
            this.orderrecivedate.ThemeName = "TelerikMetroBlue";
            this.orderrecivedate.Value = new System.DateTime(((long)(0)));
            // 
            // customerdebitmemonumber
            // 
            this.customerdebitmemonumber.Location = new System.Drawing.Point(168, 126);
            this.customerdebitmemonumber.Name = "customerdebitmemonumber";
            this.customerdebitmemonumber.Size = new System.Drawing.Size(160, 20);
            this.customerdebitmemonumber.TabIndex = 14;
            // 
            // customerrepairorderno
            // 
            this.customerrepairorderno.Location = new System.Drawing.Point(168, 104);
            this.customerrepairorderno.Name = "customerrepairorderno";
            this.customerrepairorderno.Size = new System.Drawing.Size(160, 20);
            this.customerrepairorderno.TabIndex = 13;
            // 
            // orderrepairno
            // 
            this.orderrepairno.Location = new System.Drawing.Point(168, 11);
            this.orderrepairno.Name = "orderrepairno";
            this.orderrepairno.ReadOnly = true;
            this.orderrepairno.Size = new System.Drawing.Size(160, 20);
            this.orderrepairno.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 130);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(143, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Customer Debit Memo No.";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(146, 13);
            this.label11.TabIndex = 5;
            this.label11.Text = "Customer Repair Order No.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Cancel Date";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Entry Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Receive Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Repair No.";
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.Controls.Add(this.ordercountry);
            this.radGroupBox2.Controls.Add(this.orderzip);
            this.radGroupBox2.Controls.Add(this.orderstate);
            this.radGroupBox2.Controls.Add(this.ordercity);
            this.radGroupBox2.Controls.Add(this.orderadd2);
            this.radGroupBox2.Controls.Add(this.orderadd1);
            this.radGroupBox2.Controls.Add(this.ordshipto);
            this.radGroupBox2.Controls.Add(this.ordcustcode);
            this.radGroupBox2.Controls.Add(this.label6);
            this.radGroupBox2.Controls.Add(this.label5);
            this.radGroupBox2.Controls.Add(this.label4);
            this.radGroupBox2.Controls.Add(this.label3);
            this.radGroupBox2.Controls.Add(this.Address);
            this.radGroupBox2.Controls.Add(this.label2);
            this.radGroupBox2.Controls.Add(this.label1);
            this.radGroupBox2.HeaderText = "";
            this.radGroupBox2.Location = new System.Drawing.Point(11, 24);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(335, 175);
            this.radGroupBox2.TabIndex = 67;
            // 
            // ordercountry
            // 
            this.ordercountry.Location = new System.Drawing.Point(110, 148);
            this.ordercountry.Name = "ordercountry";
            this.ordercountry.Size = new System.Drawing.Size(200, 20);
            this.ordercountry.TabIndex = 8;
            // 
            // orderzip
            // 
            this.orderzip.Location = new System.Drawing.Point(210, 126);
            this.orderzip.MaxLength = 5;
            this.orderzip.Name = "orderzip";
            this.orderzip.Size = new System.Drawing.Size(100, 20);
            this.orderzip.TabIndex = 7;
            // 
            // orderstate
            // 
            this.orderstate.Location = new System.Drawing.Point(110, 126);
            this.orderstate.MaxLength = 2;
            this.orderstate.Name = "orderstate";
            this.orderstate.Size = new System.Drawing.Size(65, 20);
            this.orderstate.TabIndex = 6;
            // 
            // ordercity
            // 
            this.ordercity.Location = new System.Drawing.Point(110, 104);
            this.ordercity.Name = "ordercity";
            this.ordercity.Size = new System.Drawing.Size(200, 20);
            this.ordercity.TabIndex = 5;
            // 
            // orderadd2
            // 
            this.orderadd2.Location = new System.Drawing.Point(110, 81);
            this.orderadd2.Name = "orderadd2";
            this.orderadd2.Size = new System.Drawing.Size(200, 20);
            this.orderadd2.TabIndex = 4;
            // 
            // orderadd1
            // 
            this.orderadd1.Location = new System.Drawing.Point(110, 56);
            this.orderadd1.Name = "orderadd1";
            this.orderadd1.Size = new System.Drawing.Size(200, 20);
            this.orderadd1.TabIndex = 3;
            // 
            // ordshipto
            // 
            this.ordshipto.Location = new System.Drawing.Point(110, 33);
            this.ordshipto.Name = "ordshipto";
            this.ordshipto.Size = new System.Drawing.Size(200, 20);
            this.ordshipto.TabIndex = 2;
            // 
            // ordcustcode
            // 
            this.ordcustcode.Location = new System.Drawing.Point(110, 11);
            this.ordcustcode.Name = "ordcustcode";
            this.ordcustcode.ReadOnly = true;
            this.ordcustcode.Size = new System.Drawing.Size(200, 20);
            this.ordcustcode.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 152);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Country";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(190, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Zip";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "State";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "City";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(21, 60);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(48, 13);
            this.Address.TabIndex = 2;
            this.Address.Text = "Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ship To";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Code";
            // 
            // totalqty
            // 
            this.totalqty.Location = new System.Drawing.Point(265, 491);
            this.totalqty.Name = "totalqty";
            this.totalqty.ReadOnly = true;
            this.totalqty.Size = new System.Drawing.Size(64, 20);
            this.totalqty.TabIndex = 77;
            // 
            // radLabel4
            // 
            this.radLabel4.Location = new System.Drawing.Point(204, 491);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(55, 18);
            this.radLabel4.TabIndex = 76;
            this.radLabel4.Text = "Total Qty:";
            // 
            // frmEditRepairOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.radButton2;
            this.ClientSize = new System.Drawing.Size(750, 614);
            this.Controls.Add(this.totalqty);
            this.Controls.Add(this.radLabel4);
            this.Controls.Add(this.radGridView1);
            this.Controls.Add(this.radButton2);
            this.Controls.Add(this.radButton1);
            this.Controls.Add(this.repairordernote);
            this.Controls.Add(this.radLabel3);
            this.Controls.Add(this.ordercreditrepair);
            this.Controls.Add(this.radGroupBox4);
            this.Controls.Add(this.radLabel10);
            this.Controls.Add(this.radLabel1);
            this.Controls.Add(this.radLabel2);
            this.Controls.Add(this.radGroupBox3);
            this.Controls.Add(this.radGroupBox2);
            this.Name = "frmEditRepairOrder";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Edit Repair Order";
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairordernote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordercreditrepair)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).EndInit();
            this.radGroupBox4.ResumeLayout(false);
            this.radGroupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.orderresidential)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox7)).EndInit();
            this.radGroupBox7.ResumeLayout(false);
            this.radGroupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyupsserver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyregular)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyearlyam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox6)).EndInit();
            this.radGroupBox6.ResumeLayout(false);
            this.radGroupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbysaturday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipby3day)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyaaa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipby2day)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbynone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbymail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbynextday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipby2dayletter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbypickup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbyredletter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbydelivery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox5)).EndInit();
            this.radGroupBox5.ResumeLayout(false);
            this.radGroupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shipbycodcheck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbycodcash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbynoncode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).EndInit();
            this.radGroupBox3.ResumeLayout(false);
            this.radGroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ordercanceldate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderentrydate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderrecivedate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerdebitmemonumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerrepairorderno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderrepairno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            this.radGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ordercountry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderstate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordercity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderadd2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderadd1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordshipto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordcustcode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalqty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadGridView radGridView1;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.UI.RadTextBoxControl repairordernote;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadCheckBox ordercreditrepair;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox4;
        private Telerik.WinControls.UI.RadCheckBox orderresidential;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox7;
        private Telerik.WinControls.UI.RadRadioButton shipbyupsserver;
        private Telerik.WinControls.UI.RadRadioButton shipbyregular;
        private Telerik.WinControls.UI.RadRadioButton shipbyearlyam;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox6;
        private Telerik.WinControls.UI.RadRadioButton shipbyground;
        private Telerik.WinControls.UI.RadRadioButton shipbysaturday;
        private Telerik.WinControls.UI.RadRadioButton shipby3day;
        private Telerik.WinControls.UI.RadRadioButton shipbyaaa;
        private Telerik.WinControls.UI.RadRadioButton shipby2day;
        private Telerik.WinControls.UI.RadRadioButton shipbynone;
        private Telerik.WinControls.UI.RadRadioButton shipbymail;
        private Telerik.WinControls.UI.RadRadioButton shipbynextday;
        private Telerik.WinControls.UI.RadRadioButton shipby2dayletter;
        private Telerik.WinControls.UI.RadRadioButton shipbypickup;
        private Telerik.WinControls.UI.RadRadioButton shipbyredletter;
        private Telerik.WinControls.UI.RadRadioButton shipbydelivery;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox5;
        private Telerik.WinControls.UI.RadRadioButton shipbycodcheck;
        private Telerik.WinControls.UI.RadRadioButton shipbycodcash;
        private Telerik.WinControls.UI.RadRadioButton shipbynoncode;
        private Telerik.WinControls.UI.RadLabel radLabel10;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox3;
        private Telerik.WinControls.UI.RadDateTimePicker ordercanceldate;
        private Telerik.WinControls.UI.RadDateTimePicker orderentrydate;
        private Telerik.WinControls.UI.RadDateTimePicker orderrecivedate;
        private Telerik.WinControls.UI.RadTextBox customerdebitmemonumber;
        private Telerik.WinControls.UI.RadTextBox customerrepairorderno;
        private Telerik.WinControls.UI.RadTextBox orderrepairno;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private Telerik.WinControls.UI.RadTextBox ordercountry;
        private Telerik.WinControls.UI.RadTextBox orderzip;
        private Telerik.WinControls.UI.RadTextBox orderstate;
        private Telerik.WinControls.UI.RadTextBox ordercity;
        private Telerik.WinControls.UI.RadTextBox orderadd2;
        private Telerik.WinControls.UI.RadTextBox orderadd1;
        private Telerik.WinControls.UI.RadTextBox ordshipto;
        private Telerik.WinControls.UI.RadTextBox ordcustcode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Telerik.WinControls.UI.RadTextBox totalqty;
        private Telerik.WinControls.UI.RadLabel radLabel4;
    }
}
