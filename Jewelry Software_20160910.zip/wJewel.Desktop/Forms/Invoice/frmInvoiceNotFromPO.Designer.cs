﻿namespace IshalInc.wJewel.Desktop.Forms
{
    partial class frmInvoiceNotFromPO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInvoiceNotFromPO));
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox1 = new Telerik.WinControls.UI.RadGroupBox();
            this.txtZip1 = new Telerik.WinControls.UI.RadTextBox();
            this.txtCountry = new Telerik.WinControls.UI.RadTextBox();
            this.lblCountry1 = new Telerik.WinControls.UI.RadLabel();
            this.txtTel = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.lblTel = new Telerik.WinControls.UI.RadLabel();
            this.lblZip1 = new Telerik.WinControls.UI.RadLabel();
            this.txtState1 = new Telerik.WinControls.UI.RadTextBox();
            this.lblState1 = new Telerik.WinControls.UI.RadLabel();
            this.txtCity1 = new Telerik.WinControls.UI.RadTextBox();
            this.lblCity1 = new Telerik.WinControls.UI.RadLabel();
            this.txtAddr12 = new Telerik.WinControls.UI.RadTextBox();
            this.txtAddr1 = new Telerik.WinControls.UI.RadTextBox();
            this.lblAddress1 = new Telerik.WinControls.UI.RadLabel();
            this.txtName = new Telerik.WinControls.UI.RadTextBox();
            this.lblName = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            this.txtCountry2 = new Telerik.WinControls.UI.RadTextBox();
            this.lblCountry2 = new Telerik.WinControls.UI.RadLabel();
            this.txtZip2 = new Telerik.WinControls.UI.RadTextBox();
            this.lblZip2 = new Telerik.WinControls.UI.RadLabel();
            this.txtState2 = new Telerik.WinControls.UI.RadTextBox();
            this.lblState2 = new Telerik.WinControls.UI.RadLabel();
            this.txtCity2 = new Telerik.WinControls.UI.RadTextBox();
            this.lblCity2 = new Telerik.WinControls.UI.RadLabel();
            this.txtAddr22 = new Telerik.WinControls.UI.RadTextBox();
            this.txtAddr2 = new Telerik.WinControls.UI.RadTextBox();
            this.lblAddress2 = new Telerik.WinControls.UI.RadLabel();
            this.txtName2 = new Telerik.WinControls.UI.RadTextBox();
            this.lblName2 = new Telerik.WinControls.UI.RadLabel();
            this.chkResidentialAddress = new Telerik.WinControls.UI.RadCheckBox();
            this.radGroupBox3 = new Telerik.WinControls.UI.RadGroupBox();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.txtPONo = new Telerik.WinControls.UI.RadTextBox();
            this.lblEstdDate = new Telerik.WinControls.UI.RadLabel();
            this.txtInvoiceDate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.grpShipVia = new Telerik.WinControls.UI.RadGroupBox();
            this.rdoNextDayLetter = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoNone = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoNextDayFirst = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoPickup = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoNextDayPriority = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoDelivery = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoNextDatStd = new Telerik.WinControls.UI.RadRadioButton();
            this.rdo2Day = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoSaturday = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoMail = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoExpressSaver = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoGround = new Telerik.WinControls.UI.RadRadioButton();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.txtNote = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.lblPayTerm = new Telerik.WinControls.UI.RadLabel();
            this.txtPayTerm1 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtTermPercent1 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtPayTerm2 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtTermPercent2 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtPayTerm3 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtTermPercent3 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtPayTerm4 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtTermPercent4 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.lblPercent = new Telerik.WinControls.UI.RadLabel();
            this.grpPayterms = new Telerik.WinControls.UI.RadGroupBox();
            this.radLabel13 = new Telerik.WinControls.UI.RadLabel();
            this.chkCOD = new Telerik.WinControls.UI.RadCheckBox();
            this.radLabel14 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel18 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel19 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel17 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel20 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel16 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel21 = new Telerik.WinControls.UI.RadLabel();
            this.txtPayTerm5 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel15 = new Telerik.WinControls.UI.RadLabel();
            this.txtTermPercent5 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtPayTerm6 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtTermPercent6 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtPayTerm7 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtTermPercent7 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtPayTerm8 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtTermPercent8 = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel22 = new Telerik.WinControls.UI.RadLabel();
            this.txtInsuredFor = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.lblCreditLimit = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox4 = new Telerik.WinControls.UI.RadGroupBox();
            this.rdoUPSSaver = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoEarlyAm = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoRegular = new Telerik.WinControls.UI.RadRadioButton();
            this.txtSubTotal = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtOtherCharges = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtShippingHandling = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.txtTotal = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.btnSave = new Telerik.WinControls.UI.RadButton();
            this.btnCancel = new Telerik.WinControls.UI.RadButton();
            this.btnOK = new Telerik.WinControls.UI.RadButton();
            this.radLabel10 = new Telerik.WinControls.UI.RadLabel();
            this.txtBillingAccount = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel11 = new Telerik.WinControls.UI.RadLabel();
            this.txtInvoiceNo = new Telerik.WinControls.UI.RadTextBox();
            this.dataGridView1 = new Telerik.WinControls.UI.RadGridView();
            this.chkViaFedex = new Telerik.WinControls.UI.RadCheckBox();
            this.chkSHOverride = new Telerik.WinControls.UI.RadCheckBox();
            this.txtWeight = new Telerik.WinControls.UI.RadMaskedEditBox();
            this.radLabel12 = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).BeginInit();
            this.radGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtZip1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCountry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCountry1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblZip1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtState1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblState1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCity1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCity1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddr12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddr1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAddress1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCountry2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCountry2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZip2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblZip2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtState2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblState2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCity2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCity2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddr22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddr2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAddress2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblName2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkResidentialAddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).BeginInit();
            this.radGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPONo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEstdDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInvoiceDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpShipVia)).BeginInit();
            this.grpShipVia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayLetter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayFirst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoPickup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayPriority)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoDelivery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDatStd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo2Day)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoSaturday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoMail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoExpressSaver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoGround)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPayTerm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPercent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpPayterms)).BeginInit();
            this.grpPayterms.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCOD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInsuredFor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCreditLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).BeginInit();
            this.radGroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoUPSSaver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoEarlyAm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoRegular)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherCharges)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShippingHandling)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnOK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBillingAccount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInvoiceNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkViaFedex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSHOverride)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radLabel2
            // 
            this.radLabel2.AutoSize = false;
            this.radLabel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.radLabel2.BorderVisible = true;
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel2.ForeColor = System.Drawing.Color.White;
            this.radLabel2.Location = new System.Drawing.Point(12, 27);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(396, 18);
            this.radLabel2.TabIndex = 2;
            this.radLabel2.Text = "Billing";
            this.radLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radGroupBox1
            // 
            this.radGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox1.Controls.Add(this.txtZip1);
            this.radGroupBox1.Controls.Add(this.txtCountry);
            this.radGroupBox1.Controls.Add(this.lblCountry1);
            this.radGroupBox1.Controls.Add(this.txtTel);
            this.radGroupBox1.Controls.Add(this.lblTel);
            this.radGroupBox1.Controls.Add(this.lblZip1);
            this.radGroupBox1.Controls.Add(this.txtState1);
            this.radGroupBox1.Controls.Add(this.lblState1);
            this.radGroupBox1.Controls.Add(this.txtCity1);
            this.radGroupBox1.Controls.Add(this.lblCity1);
            this.radGroupBox1.Controls.Add(this.txtAddr12);
            this.radGroupBox1.Controls.Add(this.txtAddr1);
            this.radGroupBox1.Controls.Add(this.lblAddress1);
            this.radGroupBox1.Controls.Add(this.txtName);
            this.radGroupBox1.Controls.Add(this.lblName);
            this.radGroupBox1.HeaderText = "";
            this.radGroupBox1.Location = new System.Drawing.Point(12, 45);
            this.radGroupBox1.Name = "radGroupBox1";
            this.radGroupBox1.Size = new System.Drawing.Size(396, 132);
            this.radGroupBox1.TabIndex = 3;
            // 
            // txtZip1
            // 
            this.txtZip1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtZip1.Enabled = false;
            this.txtZip1.Location = new System.Drawing.Point(87, 88);
            this.txtZip1.MaxLength = 10;
            this.txtZip1.Name = "txtZip1";
            this.txtZip1.Size = new System.Drawing.Size(115, 20);
            this.txtZip1.TabIndex = 10;
            this.txtZip1.ThemeName = "TelerikMetroBlue";
            // 
            // txtCountry
            // 
            this.txtCountry.Enabled = false;
            this.txtCountry.Location = new System.Drawing.Point(87, 107);
            this.txtCountry.MaxLength = 15;
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(115, 20);
            this.txtCountry.TabIndex = 14;
            this.txtCountry.ThemeName = "TelerikMetroBlue";
            // 
            // lblCountry1
            // 
            this.lblCountry1.Location = new System.Drawing.Point(6, 108);
            this.lblCountry1.Name = "lblCountry1";
            this.lblCountry1.Size = new System.Drawing.Size(46, 18);
            this.lblCountry1.TabIndex = 13;
            this.lblCountry1.Text = "Country";
            this.lblCountry1.ThemeName = "TelerikMetroBlue";
            // 
            // txtTel
            // 
            this.txtTel.Enabled = false;
            this.txtTel.Location = new System.Drawing.Point(279, 88);
            this.txtTel.Mask = "(999) 000-0000";
            this.txtTel.MaskType = Telerik.WinControls.UI.MaskType.Standard;
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(112, 20);
            this.txtTel.TabIndex = 12;
            this.txtTel.TabStop = false;
            this.txtTel.Text = "(___) ___-____";
            this.txtTel.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTel.ThemeName = "TelerikMetroBlue";
            // 
            // lblTel
            // 
            this.lblTel.Location = new System.Drawing.Point(218, 89);
            this.lblTel.Name = "lblTel";
            this.lblTel.Size = new System.Drawing.Size(23, 18);
            this.lblTel.TabIndex = 11;
            this.lblTel.Text = "Tel.";
            this.lblTel.ThemeName = "TelerikMetroBlue";
            // 
            // lblZip1
            // 
            this.lblZip1.Location = new System.Drawing.Point(6, 89);
            this.lblZip1.Name = "lblZip1";
            this.lblZip1.Size = new System.Drawing.Size(51, 18);
            this.lblZip1.TabIndex = 9;
            this.lblZip1.Text = "Zip Code";
            this.lblZip1.ThemeName = "TelerikMetroBlue";
            // 
            // txtState1
            // 
            this.txtState1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtState1.Enabled = false;
            this.txtState1.Location = new System.Drawing.Point(279, 66);
            this.txtState1.MaxLength = 2;
            this.txtState1.Name = "txtState1";
            this.txtState1.Size = new System.Drawing.Size(112, 20);
            this.txtState1.TabIndex = 8;
            this.txtState1.ThemeName = "TelerikMetroBlue";
            // 
            // lblState1
            // 
            this.lblState1.Location = new System.Drawing.Point(218, 67);
            this.lblState1.Name = "lblState1";
            this.lblState1.Size = new System.Drawing.Size(32, 18);
            this.lblState1.TabIndex = 7;
            this.lblState1.Text = "State";
            this.lblState1.ThemeName = "TelerikMetroBlue";
            // 
            // txtCity1
            // 
            this.txtCity1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCity1.Enabled = false;
            this.txtCity1.Location = new System.Drawing.Point(87, 66);
            this.txtCity1.MaxLength = 15;
            this.txtCity1.Name = "txtCity1";
            this.txtCity1.Size = new System.Drawing.Size(115, 20);
            this.txtCity1.TabIndex = 6;
            this.txtCity1.ThemeName = "TelerikMetroBlue";
            // 
            // lblCity1
            // 
            this.lblCity1.Location = new System.Drawing.Point(6, 67);
            this.lblCity1.Name = "lblCity1";
            this.lblCity1.Size = new System.Drawing.Size(25, 18);
            this.lblCity1.TabIndex = 5;
            this.lblCity1.Text = "City";
            this.lblCity1.ThemeName = "TelerikMetroBlue";
            // 
            // txtAddr12
            // 
            this.txtAddr12.Enabled = false;
            this.txtAddr12.Location = new System.Drawing.Point(87, 47);
            this.txtAddr12.MaxLength = 30;
            this.txtAddr12.Name = "txtAddr12";
            this.txtAddr12.Size = new System.Drawing.Size(304, 20);
            this.txtAddr12.TabIndex = 4;
            this.txtAddr12.ThemeName = "TelerikMetroBlue";
            // 
            // txtAddr1
            // 
            this.txtAddr1.Enabled = false;
            this.txtAddr1.Location = new System.Drawing.Point(87, 28);
            this.txtAddr1.MaxLength = 30;
            this.txtAddr1.Name = "txtAddr1";
            this.txtAddr1.Size = new System.Drawing.Size(304, 20);
            this.txtAddr1.TabIndex = 3;
            this.txtAddr1.ThemeName = "TelerikMetroBlue";
            // 
            // lblAddress1
            // 
            this.lblAddress1.Location = new System.Drawing.Point(6, 31);
            this.lblAddress1.Name = "lblAddress1";
            this.lblAddress1.Size = new System.Drawing.Size(46, 18);
            this.lblAddress1.TabIndex = 2;
            this.lblAddress1.Text = "Address";
            this.lblAddress1.ThemeName = "TelerikMetroBlue";
            // 
            // txtName
            // 
            this.txtName.Enabled = false;
            this.txtName.Location = new System.Drawing.Point(87, 5);
            this.txtName.MaxLength = 30;
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(304, 20);
            this.txtName.TabIndex = 1;
            this.txtName.ThemeName = "TelerikMetroBlue";
            // 
            // lblName
            // 
            this.lblName.Location = new System.Drawing.Point(6, 6);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(39, 18);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Bill To:";
            this.lblName.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel3
            // 
            this.radLabel3.AutoSize = false;
            this.radLabel3.BackColor = System.Drawing.Color.RoyalBlue;
            this.radLabel3.BorderVisible = true;
            this.radLabel3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel3.ForeColor = System.Drawing.Color.White;
            this.radLabel3.Location = new System.Drawing.Point(435, 27);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(396, 18);
            this.radLabel3.TabIndex = 6;
            this.radLabel3.Text = "Shipping";
            this.radLabel3.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.Controls.Add(this.txtCountry2);
            this.radGroupBox2.Controls.Add(this.lblCountry2);
            this.radGroupBox2.Controls.Add(this.txtZip2);
            this.radGroupBox2.Controls.Add(this.lblZip2);
            this.radGroupBox2.Controls.Add(this.txtState2);
            this.radGroupBox2.Controls.Add(this.lblState2);
            this.radGroupBox2.Controls.Add(this.txtCity2);
            this.radGroupBox2.Controls.Add(this.lblCity2);
            this.radGroupBox2.Controls.Add(this.txtAddr22);
            this.radGroupBox2.Controls.Add(this.txtAddr2);
            this.radGroupBox2.Controls.Add(this.lblAddress2);
            this.radGroupBox2.Controls.Add(this.txtName2);
            this.radGroupBox2.Controls.Add(this.lblName2);
            this.radGroupBox2.HeaderText = "";
            this.radGroupBox2.Location = new System.Drawing.Point(435, 45);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(396, 132);
            this.radGroupBox2.TabIndex = 7;
            // 
            // txtCountry2
            // 
            this.txtCountry2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCountry2.Location = new System.Drawing.Point(87, 108);
            this.txtCountry2.MaxLength = 15;
            this.txtCountry2.Name = "txtCountry2";
            this.txtCountry2.Size = new System.Drawing.Size(115, 20);
            this.txtCountry2.TabIndex = 12;
            this.txtCountry2.ThemeName = "TelerikMetroBlue";
            // 
            // lblCountry2
            // 
            this.lblCountry2.Location = new System.Drawing.Point(6, 109);
            this.lblCountry2.Name = "lblCountry2";
            this.lblCountry2.Size = new System.Drawing.Size(46, 18);
            this.lblCountry2.TabIndex = 11;
            this.lblCountry2.Text = "Country";
            this.lblCountry2.ThemeName = "TelerikMetroBlue";
            // 
            // txtZip2
            // 
            this.txtZip2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtZip2.Location = new System.Drawing.Point(87, 89);
            this.txtZip2.MaxLength = 10;
            this.txtZip2.Name = "txtZip2";
            this.txtZip2.Size = new System.Drawing.Size(115, 20);
            this.txtZip2.TabIndex = 10;
            this.txtZip2.ThemeName = "TelerikMetroBlue";
            // 
            // lblZip2
            // 
            this.lblZip2.Location = new System.Drawing.Point(6, 90);
            this.lblZip2.Name = "lblZip2";
            this.lblZip2.Size = new System.Drawing.Size(51, 18);
            this.lblZip2.TabIndex = 9;
            this.lblZip2.Text = "Zip Code";
            this.lblZip2.ThemeName = "TelerikMetroBlue";
            // 
            // txtState2
            // 
            this.txtState2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtState2.Location = new System.Drawing.Point(279, 67);
            this.txtState2.MaxLength = 2;
            this.txtState2.Name = "txtState2";
            this.txtState2.Size = new System.Drawing.Size(112, 20);
            this.txtState2.TabIndex = 8;
            this.txtState2.ThemeName = "TelerikMetroBlue";
            // 
            // lblState2
            // 
            this.lblState2.Location = new System.Drawing.Point(240, 68);
            this.lblState2.Name = "lblState2";
            this.lblState2.Size = new System.Drawing.Size(32, 18);
            this.lblState2.TabIndex = 7;
            this.lblState2.Text = "State";
            this.lblState2.ThemeName = "TelerikMetroBlue";
            // 
            // txtCity2
            // 
            this.txtCity2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCity2.Location = new System.Drawing.Point(87, 67);
            this.txtCity2.MaxLength = 15;
            this.txtCity2.Name = "txtCity2";
            this.txtCity2.Size = new System.Drawing.Size(115, 20);
            this.txtCity2.TabIndex = 6;
            this.txtCity2.ThemeName = "TelerikMetroBlue";
            // 
            // lblCity2
            // 
            this.lblCity2.Location = new System.Drawing.Point(6, 68);
            this.lblCity2.Name = "lblCity2";
            this.lblCity2.Size = new System.Drawing.Size(25, 18);
            this.lblCity2.TabIndex = 5;
            this.lblCity2.Text = "City";
            this.lblCity2.ThemeName = "TelerikMetroBlue";
            // 
            // txtAddr22
            // 
            this.txtAddr22.Location = new System.Drawing.Point(87, 48);
            this.txtAddr22.MaxLength = 30;
            this.txtAddr22.Name = "txtAddr22";
            this.txtAddr22.Size = new System.Drawing.Size(304, 20);
            this.txtAddr22.TabIndex = 4;
            this.txtAddr22.ThemeName = "TelerikMetroBlue";
            // 
            // txtAddr2
            // 
            this.txtAddr2.Location = new System.Drawing.Point(87, 29);
            this.txtAddr2.MaxLength = 30;
            this.txtAddr2.Name = "txtAddr2";
            this.txtAddr2.Size = new System.Drawing.Size(304, 20);
            this.txtAddr2.TabIndex = 3;
            this.txtAddr2.ThemeName = "TelerikMetroBlue";
            // 
            // lblAddress2
            // 
            this.lblAddress2.Location = new System.Drawing.Point(6, 30);
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.Size = new System.Drawing.Size(46, 18);
            this.lblAddress2.TabIndex = 2;
            this.lblAddress2.Text = "Address";
            this.lblAddress2.ThemeName = "TelerikMetroBlue";
            // 
            // txtName2
            // 
            this.txtName2.Location = new System.Drawing.Point(87, 6);
            this.txtName2.MaxLength = 30;
            this.txtName2.Name = "txtName2";
            this.txtName2.Size = new System.Drawing.Size(304, 20);
            this.txtName2.TabIndex = 1;
            this.txtName2.ThemeName = "TelerikMetroBlue";
            // 
            // lblName2
            // 
            this.lblName2.Location = new System.Drawing.Point(6, 7);
            this.lblName2.Name = "lblName2";
            this.lblName2.Size = new System.Drawing.Size(46, 18);
            this.lblName2.TabIndex = 0;
            this.lblName2.Text = "Ship To:";
            this.lblName2.ThemeName = "TelerikMetroBlue";
            // 
            // chkResidentialAddress
            // 
            this.chkResidentialAddress.Location = new System.Drawing.Point(424, 2);
            this.chkResidentialAddress.Name = "chkResidentialAddress";
            this.chkResidentialAddress.Size = new System.Drawing.Size(118, 18);
            this.chkResidentialAddress.TabIndex = 4;
            this.chkResidentialAddress.Text = "Residential Address";
            this.chkResidentialAddress.ThemeName = "TelerikMetroBlue";
            // 
            // radGroupBox3
            // 
            this.radGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox3.Controls.Add(this.radLabel1);
            this.radGroupBox3.Controls.Add(this.txtPONo);
            this.radGroupBox3.Controls.Add(this.lblEstdDate);
            this.radGroupBox3.Controls.Add(this.txtInvoiceDate);
            this.radGroupBox3.Controls.Add(this.chkResidentialAddress);
            this.radGroupBox3.HeaderText = "";
            this.radGroupBox3.Location = new System.Drawing.Point(12, 178);
            this.radGroupBox3.Name = "radGroupBox3";
            this.radGroupBox3.Size = new System.Drawing.Size(819, 25);
            this.radGroupBox3.TabIndex = 7;
            // 
            // radLabel1
            // 
            this.radLabel1.Location = new System.Drawing.Point(218, 3);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(31, 18);
            this.radLabel1.TabIndex = 2;
            this.radLabel1.Text = "PO #";
            this.radLabel1.ThemeName = "TelerikMetroBlue";
            // 
            // txtPONo
            // 
            this.txtPONo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPONo.Location = new System.Drawing.Point(279, 2);
            this.txtPONo.MaxLength = 10;
            this.txtPONo.Name = "txtPONo";
            this.txtPONo.Size = new System.Drawing.Size(112, 20);
            this.txtPONo.TabIndex = 3;
            this.txtPONo.ThemeName = "TelerikMetroBlue";
            // 
            // lblEstdDate
            // 
            this.lblEstdDate.Location = new System.Drawing.Point(6, 3);
            this.lblEstdDate.Name = "lblEstdDate";
            this.lblEstdDate.Size = new System.Drawing.Size(68, 18);
            this.lblEstdDate.TabIndex = 0;
            this.lblEstdDate.Text = "Invoice Date";
            this.lblEstdDate.ThemeName = "TelerikMetroBlue";
            // 
            // txtInvoiceDate
            // 
            this.txtInvoiceDate.CustomFormat = "\"\"";
            this.txtInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtInvoiceDate.Location = new System.Drawing.Point(87, 2);
            this.txtInvoiceDate.Name = "txtInvoiceDate";
            this.txtInvoiceDate.Size = new System.Drawing.Size(126, 20);
            this.txtInvoiceDate.TabIndex = 1;
            this.txtInvoiceDate.TabStop = false;
            this.txtInvoiceDate.Text = "4/14/16";
            this.txtInvoiceDate.ThemeName = "TelerikMetroBlue";
            this.txtInvoiceDate.Value = new System.DateTime(2016, 4, 14, 13, 37, 1, 295);
            // 
            // radLabel4
            // 
            this.radLabel4.AutoSize = false;
            this.radLabel4.BackColor = System.Drawing.Color.Fuchsia;
            this.radLabel4.BorderVisible = true;
            this.radLabel4.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel4.ForeColor = System.Drawing.Color.White;
            this.radLabel4.Location = new System.Drawing.Point(428, 435);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(403, 18);
            this.radLabel4.TabIndex = 15;
            this.radLabel4.Text = "Ship Via";
            this.radLabel4.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grpShipVia
            // 
            this.grpShipVia.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.grpShipVia.Controls.Add(this.rdoNextDayLetter);
            this.grpShipVia.Controls.Add(this.rdoNone);
            this.grpShipVia.Controls.Add(this.rdoNextDayFirst);
            this.grpShipVia.Controls.Add(this.rdoPickup);
            this.grpShipVia.Controls.Add(this.rdoNextDayPriority);
            this.grpShipVia.Controls.Add(this.rdoDelivery);
            this.grpShipVia.Controls.Add(this.rdoNextDatStd);
            this.grpShipVia.Controls.Add(this.rdo2Day);
            this.grpShipVia.Controls.Add(this.rdoSaturday);
            this.grpShipVia.Controls.Add(this.rdoMail);
            this.grpShipVia.Controls.Add(this.rdoExpressSaver);
            this.grpShipVia.Controls.Add(this.rdoGround);
            this.grpShipVia.HeaderText = "/";
            this.grpShipVia.Location = new System.Drawing.Point(428, 445);
            this.grpShipVia.Name = "grpShipVia";
            this.grpShipVia.Size = new System.Drawing.Size(403, 68);
            this.grpShipVia.TabIndex = 16;
            this.grpShipVia.TabStop = false;
            this.grpShipVia.Text = "/";
            this.grpShipVia.ThemeName = "TelerikMetroBlue";
            // 
            // rdoNextDayLetter
            // 
            this.rdoNextDayLetter.Location = new System.Drawing.Point(228, 11);
            this.rdoNextDayLetter.Name = "rdoNextDayLetter";
            this.rdoNextDayLetter.Size = new System.Drawing.Size(98, 18);
            this.rdoNextDayLetter.TabIndex = 7;
            this.rdoNextDayLetter.Text = "Next Day Letter";
            this.rdoNextDayLetter.ThemeName = "TelerikMetroBlue";
            this.rdoNextDayLetter.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoNone
            // 
            this.rdoNone.CheckState = System.Windows.Forms.CheckState.Checked;
            this.rdoNone.Location = new System.Drawing.Point(336, 47);
            this.rdoNone.Name = "rdoNone";
            this.rdoNone.Size = new System.Drawing.Size(48, 18);
            this.rdoNone.TabIndex = 0;
            this.rdoNone.Text = "None";
            this.rdoNone.ThemeName = "TelerikMetroBlue";
            this.rdoNone.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            this.rdoNone.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoNextDayFirst
            // 
            this.rdoNextDayFirst.Location = new System.Drawing.Point(114, 47);
            this.rdoNextDayFirst.Name = "rdoNextDayFirst";
            this.rdoNextDayFirst.Size = new System.Drawing.Size(90, 18);
            this.rdoNextDayFirst.TabIndex = 6;
            this.rdoNextDayFirst.Text = "Next Day First";
            this.rdoNextDayFirst.ThemeName = "TelerikMetroBlue";
            this.rdoNextDayFirst.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoPickup
            // 
            this.rdoPickup.Location = new System.Drawing.Point(336, 29);
            this.rdoPickup.Name = "rdoPickup";
            this.rdoPickup.Size = new System.Drawing.Size(53, 18);
            this.rdoPickup.TabIndex = 11;
            this.rdoPickup.Text = "Pickup";
            this.rdoPickup.ThemeName = "TelerikMetroBlue";
            this.rdoPickup.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoNextDayPriority
            // 
            this.rdoNextDayPriority.Location = new System.Drawing.Point(114, 29);
            this.rdoNextDayPriority.Name = "rdoNextDayPriority";
            this.rdoNextDayPriority.Size = new System.Drawing.Size(105, 18);
            this.rdoNextDayPriority.TabIndex = 5;
            this.rdoNextDayPriority.Text = "Next Day Priority";
            this.rdoNextDayPriority.ThemeName = "TelerikMetroBlue";
            this.rdoNextDayPriority.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoDelivery
            // 
            this.rdoDelivery.Location = new System.Drawing.Point(336, 11);
            this.rdoDelivery.Name = "rdoDelivery";
            this.rdoDelivery.Size = new System.Drawing.Size(60, 18);
            this.rdoDelivery.TabIndex = 10;
            this.rdoDelivery.Text = "Delivery";
            this.rdoDelivery.ThemeName = "TelerikMetroBlue";
            this.rdoDelivery.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoNextDatStd
            // 
            this.rdoNextDatStd.Location = new System.Drawing.Point(114, 11);
            this.rdoNextDatStd.Name = "rdoNextDatStd";
            this.rdoNextDatStd.Size = new System.Drawing.Size(86, 18);
            this.rdoNextDatStd.TabIndex = 4;
            this.rdoNextDatStd.Text = "Next Day Std";
            this.rdoNextDatStd.ThemeName = "TelerikMetroBlue";
            this.rdoNextDatStd.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdo2Day
            // 
            this.rdo2Day.Location = new System.Drawing.Point(13, 47);
            this.rdo2Day.Name = "rdo2Day";
            this.rdo2Day.Size = new System.Drawing.Size(49, 18);
            this.rdo2Day.TabIndex = 3;
            this.rdo2Day.Text = "2 Day";
            this.rdo2Day.ThemeName = "TelerikMetroBlue";
            this.rdo2Day.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoSaturday
            // 
            this.rdoSaturday.Location = new System.Drawing.Point(228, 29);
            this.rdoSaturday.Name = "rdoSaturday";
            this.rdoSaturday.Size = new System.Drawing.Size(64, 18);
            this.rdoSaturday.TabIndex = 8;
            this.rdoSaturday.Text = "Saturday";
            this.rdoSaturday.ThemeName = "TelerikMetroBlue";
            this.rdoSaturday.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoMail
            // 
            this.rdoMail.Location = new System.Drawing.Point(228, 47);
            this.rdoMail.Name = "rdoMail";
            this.rdoMail.Size = new System.Drawing.Size(42, 18);
            this.rdoMail.TabIndex = 9;
            this.rdoMail.Text = "Mail";
            this.rdoMail.ThemeName = "TelerikMetroBlue";
            this.rdoMail.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoExpressSaver
            // 
            this.rdoExpressSaver.Location = new System.Drawing.Point(13, 29);
            this.rdoExpressSaver.Name = "rdoExpressSaver";
            this.rdoExpressSaver.Size = new System.Drawing.Size(87, 18);
            this.rdoExpressSaver.TabIndex = 2;
            this.rdoExpressSaver.Text = "Express Saver";
            this.rdoExpressSaver.ThemeName = "TelerikMetroBlue";
            this.rdoExpressSaver.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // rdoGround
            // 
            this.rdoGround.Location = new System.Drawing.Point(13, 11);
            this.rdoGround.Name = "rdoGround";
            this.rdoGround.Size = new System.Drawing.Size(58, 18);
            this.rdoGround.TabIndex = 1;
            this.rdoGround.Text = "Ground";
            this.rdoGround.ThemeName = "TelerikMetroBlue";
            this.rdoGround.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoGround_ToggleStateChanged);
            // 
            // radLabel5
            // 
            this.radLabel5.Location = new System.Drawing.Point(12, 435);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(31, 18);
            this.radLabel5.TabIndex = 9;
            this.radLabel5.Text = "Note";
            this.radLabel5.ThemeName = "TelerikMetroBlue";
            // 
            // txtNote
            // 
            this.txtNote.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtNote.Location = new System.Drawing.Point(87, 435);
            this.txtNote.MaxLength = 100;
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(321, 20);
            this.txtNote.TabIndex = 10;
            this.txtNote.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel6
            // 
            this.radLabel6.AutoSize = false;
            this.radLabel6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.radLabel6.BorderVisible = true;
            this.radLabel6.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel6.ForeColor = System.Drawing.Color.White;
            this.radLabel6.Location = new System.Drawing.Point(12, 486);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(396, 18);
            this.radLabel6.TabIndex = 17;
            this.radLabel6.Text = "Pay Terms";
            this.radLabel6.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPayTerm
            // 
            this.lblPayTerm.Location = new System.Drawing.Point(4, 3);
            this.lblPayTerm.Name = "lblPayTerm";
            this.lblPayTerm.Size = new System.Drawing.Size(50, 18);
            this.lblPayTerm.TabIndex = 0;
            this.lblPayTerm.Text = "Pay.term";
            this.lblPayTerm.ThemeName = "TelerikMetroBlue";
            // 
            // txtPayTerm1
            // 
            this.txtPayTerm1.Location = new System.Drawing.Point(4, 24);
            this.txtPayTerm1.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtPayTerm1.Name = "txtPayTerm1";
            this.txtPayTerm1.Size = new System.Drawing.Size(59, 20);
            this.txtPayTerm1.TabIndex = 1;
            this.txtPayTerm1.TabStop = false;
            this.txtPayTerm1.Text = "0";
            this.txtPayTerm1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayTerm1.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtPayTerm1.ThemeName = "TelerikMetroBlue";
            // 
            // txtTermPercent1
            // 
            this.txtTermPercent1.Location = new System.Drawing.Point(68, 24);
            this.txtTermPercent1.Mask = "N2";
            this.txtTermPercent1.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTermPercent1.Name = "txtTermPercent1";
            this.txtTermPercent1.Size = new System.Drawing.Size(67, 20);
            this.txtTermPercent1.TabIndex = 2;
            this.txtTermPercent1.TabStop = false;
            this.txtTermPercent1.Text = "0.00";
            this.txtTermPercent1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTermPercent1.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTermPercent1.ThemeName = "TelerikMetroBlue";
            // 
            // txtPayTerm2
            // 
            this.txtPayTerm2.Location = new System.Drawing.Point(4, 46);
            this.txtPayTerm2.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtPayTerm2.Name = "txtPayTerm2";
            this.txtPayTerm2.Size = new System.Drawing.Size(59, 20);
            this.txtPayTerm2.TabIndex = 3;
            this.txtPayTerm2.TabStop = false;
            this.txtPayTerm2.Text = "0";
            this.txtPayTerm2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayTerm2.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtPayTerm2.ThemeName = "TelerikMetroBlue";
            // 
            // txtTermPercent2
            // 
            this.txtTermPercent2.Location = new System.Drawing.Point(68, 46);
            this.txtTermPercent2.Mask = "N2";
            this.txtTermPercent2.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTermPercent2.Name = "txtTermPercent2";
            this.txtTermPercent2.Size = new System.Drawing.Size(67, 20);
            this.txtTermPercent2.TabIndex = 4;
            this.txtTermPercent2.TabStop = false;
            this.txtTermPercent2.Text = "0.00";
            this.txtTermPercent2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTermPercent2.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTermPercent2.ThemeName = "TelerikMetroBlue";
            // 
            // txtPayTerm3
            // 
            this.txtPayTerm3.Location = new System.Drawing.Point(4, 68);
            this.txtPayTerm3.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtPayTerm3.Name = "txtPayTerm3";
            this.txtPayTerm3.Size = new System.Drawing.Size(59, 20);
            this.txtPayTerm3.TabIndex = 5;
            this.txtPayTerm3.TabStop = false;
            this.txtPayTerm3.Text = "0";
            this.txtPayTerm3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayTerm3.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtPayTerm3.ThemeName = "TelerikMetroBlue";
            // 
            // txtTermPercent3
            // 
            this.txtTermPercent3.Location = new System.Drawing.Point(68, 68);
            this.txtTermPercent3.Mask = "N2";
            this.txtTermPercent3.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTermPercent3.Name = "txtTermPercent3";
            this.txtTermPercent3.Size = new System.Drawing.Size(67, 20);
            this.txtTermPercent3.TabIndex = 6;
            this.txtTermPercent3.TabStop = false;
            this.txtTermPercent3.Text = "0.00";
            this.txtTermPercent3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTermPercent3.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTermPercent3.ThemeName = "TelerikMetroBlue";
            // 
            // txtPayTerm4
            // 
            this.txtPayTerm4.Location = new System.Drawing.Point(4, 89);
            this.txtPayTerm4.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtPayTerm4.Name = "txtPayTerm4";
            this.txtPayTerm4.Size = new System.Drawing.Size(59, 20);
            this.txtPayTerm4.TabIndex = 7;
            this.txtPayTerm4.TabStop = false;
            this.txtPayTerm4.Text = "0";
            this.txtPayTerm4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayTerm4.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtPayTerm4.ThemeName = "TelerikMetroBlue";
            // 
            // txtTermPercent4
            // 
            this.txtTermPercent4.Location = new System.Drawing.Point(68, 89);
            this.txtTermPercent4.Mask = "N2";
            this.txtTermPercent4.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTermPercent4.Name = "txtTermPercent4";
            this.txtTermPercent4.Size = new System.Drawing.Size(67, 20);
            this.txtTermPercent4.TabIndex = 8;
            this.txtTermPercent4.TabStop = false;
            this.txtTermPercent4.Text = "0.00";
            this.txtTermPercent4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTermPercent4.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTermPercent4.ThemeName = "TelerikMetroBlue";
            // 
            // lblPercent
            // 
            this.lblPercent.Location = new System.Drawing.Point(68, 3);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(44, 18);
            this.lblPercent.TabIndex = 2;
            this.lblPercent.Text = "Percent";
            this.lblPercent.ThemeName = "TelerikMetroBlue";
            // 
            // grpPayterms
            // 
            this.grpPayterms.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.grpPayterms.Controls.Add(this.radLabel13);
            this.grpPayterms.Controls.Add(this.chkCOD);
            this.grpPayterms.Controls.Add(this.radLabel14);
            this.grpPayterms.Controls.Add(this.radLabel18);
            this.grpPayterms.Controls.Add(this.radLabel19);
            this.grpPayterms.Controls.Add(this.radLabel17);
            this.grpPayterms.Controls.Add(this.radLabel20);
            this.grpPayterms.Controls.Add(this.radLabel16);
            this.grpPayterms.Controls.Add(this.radLabel21);
            this.grpPayterms.Controls.Add(this.txtPayTerm5);
            this.grpPayterms.Controls.Add(this.radLabel15);
            this.grpPayterms.Controls.Add(this.txtTermPercent5);
            this.grpPayterms.Controls.Add(this.lblPayTerm);
            this.grpPayterms.Controls.Add(this.txtPayTerm6);
            this.grpPayterms.Controls.Add(this.txtPayTerm1);
            this.grpPayterms.Controls.Add(this.txtTermPercent6);
            this.grpPayterms.Controls.Add(this.txtTermPercent1);
            this.grpPayterms.Controls.Add(this.txtPayTerm7);
            this.grpPayterms.Controls.Add(this.txtPayTerm2);
            this.grpPayterms.Controls.Add(this.txtTermPercent7);
            this.grpPayterms.Controls.Add(this.txtTermPercent2);
            this.grpPayterms.Controls.Add(this.txtPayTerm8);
            this.grpPayterms.Controls.Add(this.txtPayTerm3);
            this.grpPayterms.Controls.Add(this.txtTermPercent8);
            this.grpPayterms.Controls.Add(this.txtTermPercent3);
            this.grpPayterms.Controls.Add(this.radLabel22);
            this.grpPayterms.Controls.Add(this.txtPayTerm4);
            this.grpPayterms.Controls.Add(this.txtTermPercent4);
            this.grpPayterms.Controls.Add(this.lblPercent);
            this.grpPayterms.HeaderText = "";
            this.grpPayterms.Location = new System.Drawing.Point(12, 504);
            this.grpPayterms.Name = "grpPayterms";
            this.grpPayterms.Size = new System.Drawing.Size(396, 116);
            this.grpPayterms.TabIndex = 16;
            // 
            // radLabel13
            // 
            this.radLabel13.Location = new System.Drawing.Point(300, 90);
            this.radLabel13.Name = "radLabel13";
            this.radLabel13.Size = new System.Drawing.Size(15, 18);
            this.radLabel13.TabIndex = 39;
            this.radLabel13.Text = "%";
            this.radLabel13.ThemeName = "TelerikMetroBlue";
            // 
            // chkCOD
            // 
            this.chkCOD.Location = new System.Drawing.Point(333, 24);
            this.chkCOD.Name = "chkCOD";
            this.chkCOD.Size = new System.Drawing.Size(44, 18);
            this.chkCOD.TabIndex = 17;
            this.chkCOD.Text = "COD";
            this.chkCOD.ThemeName = "TelerikMetroBlue";
            this.chkCOD.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.chkCOD_ToggleStateChanged);
            // 
            // radLabel14
            // 
            this.radLabel14.Location = new System.Drawing.Point(300, 69);
            this.radLabel14.Name = "radLabel14";
            this.radLabel14.Size = new System.Drawing.Size(15, 18);
            this.radLabel14.TabIndex = 40;
            this.radLabel14.Text = "%";
            this.radLabel14.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel18
            // 
            this.radLabel18.Location = new System.Drawing.Point(141, 90);
            this.radLabel18.Name = "radLabel18";
            this.radLabel18.Size = new System.Drawing.Size(15, 18);
            this.radLabel18.TabIndex = 25;
            this.radLabel18.Text = "%";
            this.radLabel18.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel19
            // 
            this.radLabel19.Location = new System.Drawing.Point(300, 47);
            this.radLabel19.Name = "radLabel19";
            this.radLabel19.Size = new System.Drawing.Size(15, 18);
            this.radLabel19.TabIndex = 41;
            this.radLabel19.Text = "%";
            this.radLabel19.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel17
            // 
            this.radLabel17.Location = new System.Drawing.Point(141, 69);
            this.radLabel17.Name = "radLabel17";
            this.radLabel17.Size = new System.Drawing.Size(15, 18);
            this.radLabel17.TabIndex = 26;
            this.radLabel17.Text = "%";
            this.radLabel17.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel20
            // 
            this.radLabel20.Location = new System.Drawing.Point(300, 25);
            this.radLabel20.Name = "radLabel20";
            this.radLabel20.Size = new System.Drawing.Size(15, 18);
            this.radLabel20.TabIndex = 42;
            this.radLabel20.Text = "%";
            this.radLabel20.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel16
            // 
            this.radLabel16.Location = new System.Drawing.Point(141, 47);
            this.radLabel16.Name = "radLabel16";
            this.radLabel16.Size = new System.Drawing.Size(15, 18);
            this.radLabel16.TabIndex = 27;
            this.radLabel16.Text = "%";
            this.radLabel16.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel21
            // 
            this.radLabel21.Location = new System.Drawing.Point(163, 3);
            this.radLabel21.Name = "radLabel21";
            this.radLabel21.Size = new System.Drawing.Size(50, 18);
            this.radLabel21.TabIndex = 29;
            this.radLabel21.Text = "Pay.term";
            this.radLabel21.ThemeName = "TelerikMetroBlue";
            // 
            // txtPayTerm5
            // 
            this.txtPayTerm5.Location = new System.Drawing.Point(163, 24);
            this.txtPayTerm5.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtPayTerm5.Name = "txtPayTerm5";
            this.txtPayTerm5.Size = new System.Drawing.Size(59, 20);
            this.txtPayTerm5.TabIndex = 9;
            this.txtPayTerm5.TabStop = false;
            this.txtPayTerm5.Text = "0";
            this.txtPayTerm5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayTerm5.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtPayTerm5.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel15
            // 
            this.radLabel15.Location = new System.Drawing.Point(141, 25);
            this.radLabel15.Name = "radLabel15";
            this.radLabel15.Size = new System.Drawing.Size(15, 18);
            this.radLabel15.TabIndex = 28;
            this.radLabel15.Text = "%";
            this.radLabel15.ThemeName = "TelerikMetroBlue";
            // 
            // txtTermPercent5
            // 
            this.txtTermPercent5.Location = new System.Drawing.Point(227, 24);
            this.txtTermPercent5.Mask = "N2";
            this.txtTermPercent5.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTermPercent5.Name = "txtTermPercent5";
            this.txtTermPercent5.Size = new System.Drawing.Size(67, 20);
            this.txtTermPercent5.TabIndex = 10;
            this.txtTermPercent5.TabStop = false;
            this.txtTermPercent5.Text = "0.00";
            this.txtTermPercent5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTermPercent5.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTermPercent5.ThemeName = "TelerikMetroBlue";
            // 
            // txtPayTerm6
            // 
            this.txtPayTerm6.Location = new System.Drawing.Point(163, 46);
            this.txtPayTerm6.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtPayTerm6.Name = "txtPayTerm6";
            this.txtPayTerm6.Size = new System.Drawing.Size(59, 20);
            this.txtPayTerm6.TabIndex = 11;
            this.txtPayTerm6.TabStop = false;
            this.txtPayTerm6.Text = "0";
            this.txtPayTerm6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayTerm6.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtPayTerm6.ThemeName = "TelerikMetroBlue";
            // 
            // txtTermPercent6
            // 
            this.txtTermPercent6.Location = new System.Drawing.Point(227, 46);
            this.txtTermPercent6.Mask = "N2";
            this.txtTermPercent6.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTermPercent6.Name = "txtTermPercent6";
            this.txtTermPercent6.Size = new System.Drawing.Size(67, 20);
            this.txtTermPercent6.TabIndex = 12;
            this.txtTermPercent6.TabStop = false;
            this.txtTermPercent6.Text = "0.00";
            this.txtTermPercent6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTermPercent6.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTermPercent6.ThemeName = "TelerikMetroBlue";
            // 
            // txtPayTerm7
            // 
            this.txtPayTerm7.Location = new System.Drawing.Point(163, 68);
            this.txtPayTerm7.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtPayTerm7.Name = "txtPayTerm7";
            this.txtPayTerm7.Size = new System.Drawing.Size(59, 20);
            this.txtPayTerm7.TabIndex = 13;
            this.txtPayTerm7.TabStop = false;
            this.txtPayTerm7.Text = "0";
            this.txtPayTerm7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayTerm7.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtPayTerm7.ThemeName = "TelerikMetroBlue";
            // 
            // txtTermPercent7
            // 
            this.txtTermPercent7.Location = new System.Drawing.Point(227, 68);
            this.txtTermPercent7.Mask = "N2";
            this.txtTermPercent7.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTermPercent7.Name = "txtTermPercent7";
            this.txtTermPercent7.Size = new System.Drawing.Size(67, 20);
            this.txtTermPercent7.TabIndex = 14;
            this.txtTermPercent7.TabStop = false;
            this.txtTermPercent7.Text = "0.00";
            this.txtTermPercent7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTermPercent7.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTermPercent7.ThemeName = "TelerikMetroBlue";
            // 
            // txtPayTerm8
            // 
            this.txtPayTerm8.Location = new System.Drawing.Point(163, 89);
            this.txtPayTerm8.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtPayTerm8.Name = "txtPayTerm8";
            this.txtPayTerm8.Size = new System.Drawing.Size(59, 20);
            this.txtPayTerm8.TabIndex = 15;
            this.txtPayTerm8.TabStop = false;
            this.txtPayTerm8.Text = "0";
            this.txtPayTerm8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPayTerm8.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtPayTerm8.ThemeName = "TelerikMetroBlue";
            // 
            // txtTermPercent8
            // 
            this.txtTermPercent8.Location = new System.Drawing.Point(227, 89);
            this.txtTermPercent8.Mask = "N2";
            this.txtTermPercent8.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTermPercent8.Name = "txtTermPercent8";
            this.txtTermPercent8.Size = new System.Drawing.Size(67, 20);
            this.txtTermPercent8.TabIndex = 16;
            this.txtTermPercent8.TabStop = false;
            this.txtTermPercent8.Text = "0.00";
            this.txtTermPercent8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTermPercent8.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTermPercent8.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel22
            // 
            this.radLabel22.Location = new System.Drawing.Point(227, 3);
            this.radLabel22.Name = "radLabel22";
            this.radLabel22.Size = new System.Drawing.Size(44, 18);
            this.radLabel22.TabIndex = 30;
            this.radLabel22.Text = "Percent";
            this.radLabel22.ThemeName = "TelerikMetroBlue";
            // 
            // txtInsuredFor
            // 
            this.txtInsuredFor.Location = new System.Drawing.Point(87, 462);
            this.txtInsuredFor.Mask = "c";
            this.txtInsuredFor.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtInsuredFor.Name = "txtInsuredFor";
            this.txtInsuredFor.Size = new System.Drawing.Size(100, 20);
            this.txtInsuredFor.TabIndex = 12;
            this.txtInsuredFor.TabStop = false;
            this.txtInsuredFor.Text = "$0.00";
            this.txtInsuredFor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtInsuredFor.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtInsuredFor.ThemeName = "TelerikMetroBlue";
            this.txtInsuredFor.Click += new System.EventHandler(this.txtInsuredFor_Click);
            // 
            // lblCreditLimit
            // 
            this.lblCreditLimit.Location = new System.Drawing.Point(12, 463);
            this.lblCreditLimit.Name = "lblCreditLimit";
            this.lblCreditLimit.Size = new System.Drawing.Size(63, 18);
            this.lblCreditLimit.TabIndex = 11;
            this.lblCreditLimit.Text = "Insured For";
            this.lblCreditLimit.ThemeName = "TelerikMetroBlue";
            // 
            // radGroupBox4
            // 
            this.radGroupBox4.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox4.Controls.Add(this.rdoUPSSaver);
            this.radGroupBox4.Controls.Add(this.rdoEarlyAm);
            this.radGroupBox4.Controls.Add(this.rdoRegular);
            this.radGroupBox4.HeaderText = "/";
            this.radGroupBox4.Location = new System.Drawing.Point(428, 514);
            this.radGroupBox4.Name = "radGroupBox4";
            this.radGroupBox4.Size = new System.Drawing.Size(100, 77);
            this.radGroupBox4.TabIndex = 21;
            this.radGroupBox4.TabStop = false;
            this.radGroupBox4.Text = "/";
            this.radGroupBox4.ThemeName = "TelerikMetroBlue";
            // 
            // rdoUPSSaver
            // 
            this.rdoUPSSaver.Location = new System.Drawing.Point(13, 54);
            this.rdoUPSSaver.Name = "rdoUPSSaver";
            this.rdoUPSSaver.Size = new System.Drawing.Size(70, 18);
            this.rdoUPSSaver.TabIndex = 2;
            this.rdoUPSSaver.TabStop = false;
            this.rdoUPSSaver.Text = "UPS Saver";
            this.rdoUPSSaver.ThemeName = "TelerikMetroBlue";
            this.rdoUPSSaver.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoRegular_ToggleStateChanged);
            // 
            // rdoEarlyAm
            // 
            this.rdoEarlyAm.Location = new System.Drawing.Point(13, 34);
            this.rdoEarlyAm.Name = "rdoEarlyAm";
            this.rdoEarlyAm.Size = new System.Drawing.Size(64, 18);
            this.rdoEarlyAm.TabIndex = 1;
            this.rdoEarlyAm.TabStop = false;
            this.rdoEarlyAm.Text = "Early Am";
            this.rdoEarlyAm.ThemeName = "TelerikMetroBlue";
            this.rdoEarlyAm.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoRegular_ToggleStateChanged);
            // 
            // rdoRegular
            // 
            this.rdoRegular.CheckState = System.Windows.Forms.CheckState.Checked;
            this.rdoRegular.Location = new System.Drawing.Point(13, 10);
            this.rdoRegular.Name = "rdoRegular";
            this.rdoRegular.Size = new System.Drawing.Size(58, 18);
            this.rdoRegular.TabIndex = 0;
            this.rdoRegular.Text = "Regular";
            this.rdoRegular.ThemeName = "TelerikMetroBlue";
            this.rdoRegular.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            this.rdoRegular.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.rdoRegular_ToggleStateChanged);
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.Location = new System.Drawing.Point(731, 514);
            this.txtSubTotal.Mask = "c";
            this.txtSubTotal.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.ReadOnly = true;
            this.txtSubTotal.Size = new System.Drawing.Size(100, 20);
            this.txtSubTotal.TabIndex = 20;
            this.txtSubTotal.TabStop = false;
            this.txtSubTotal.Text = "$0.00";
            this.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSubTotal.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtSubTotal.ThemeName = "TelerikMetroBlue";
            this.txtSubTotal.ValueChanged += new System.EventHandler(this.txtSubTotal_ValueChanged);
            // 
            // txtOtherCharges
            // 
            this.txtOtherCharges.Location = new System.Drawing.Point(731, 533);
            this.txtOtherCharges.Mask = "c";
            this.txtOtherCharges.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtOtherCharges.Name = "txtOtherCharges";
            this.txtOtherCharges.Size = new System.Drawing.Size(100, 20);
            this.txtOtherCharges.TabIndex = 22;
            this.txtOtherCharges.TabStop = false;
            this.txtOtherCharges.Text = "$0.00";
            this.txtOtherCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtOtherCharges.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtOtherCharges.ThemeName = "TelerikMetroBlue";
            this.txtOtherCharges.ValueChanged += new System.EventHandler(this.txtOtherCharges_ValueChanged);
            // 
            // txtShippingHandling
            // 
            this.txtShippingHandling.Enabled = false;
            this.txtShippingHandling.Location = new System.Drawing.Point(731, 552);
            this.txtShippingHandling.Mask = "c";
            this.txtShippingHandling.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtShippingHandling.Name = "txtShippingHandling";
            this.txtShippingHandling.Size = new System.Drawing.Size(100, 20);
            this.txtShippingHandling.TabIndex = 24;
            this.txtShippingHandling.TabStop = false;
            this.txtShippingHandling.Text = "$0.00";
            this.txtShippingHandling.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtShippingHandling.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtShippingHandling.ThemeName = "TelerikMetroBlue";
            this.txtShippingHandling.ValueChanged += new System.EventHandler(this.txtShippingHandling_ValueChanged);
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(731, 573);
            this.txtTotal.Mask = "c";
            this.txtTotal.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(100, 20);
            this.txtTotal.TabIndex = 26;
            this.txtTotal.TabStop = false;
            this.txtTotal.Text = "$0.00";
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtTotal.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtTotal.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel7
            // 
            this.radLabel7.Location = new System.Drawing.Point(632, 515);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(51, 18);
            this.radLabel7.TabIndex = 19;
            this.radLabel7.Text = "Subtotal:";
            this.radLabel7.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel8
            // 
            this.radLabel8.Location = new System.Drawing.Point(632, 534);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(78, 18);
            this.radLabel8.TabIndex = 21;
            this.radLabel8.Text = "Other Charges";
            this.radLabel8.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel9
            // 
            this.radLabel9.Location = new System.Drawing.Point(632, 574);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(34, 18);
            this.radLabel9.TabIndex = 25;
            this.radLabel9.Text = "Total:";
            this.radLabel9.ThemeName = "TelerikMetroBlue";
            // 
            // btnSave
            // 
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.Location = new System.Drawing.Point(632, 552);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(98, 20);
            this.btnSave.TabIndex = 23;
            this.btnSave.Text = " Calc. S&&H";
            this.btnSave.ThemeName = "TelerikMetroBlue";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Location = new System.Drawing.Point(756, 595);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 28;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnOK.Image = ((System.Drawing.Image)(resources.GetObject("btnOK.Image")));
            this.btnOK.Location = new System.Drawing.Point(675, 595);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 27;
            this.btnOK.Text = "OK";
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // radLabel10
            // 
            this.radLabel10.Location = new System.Drawing.Point(14, 4);
            this.radLabel10.Name = "radLabel10";
            this.radLabel10.Size = new System.Drawing.Size(84, 18);
            this.radLabel10.TabIndex = 0;
            this.radLabel10.Text = "Customer Code";
            this.radLabel10.ThemeName = "TelerikMetroBlue";
            // 
            // txtBillingAccount
            // 
            this.txtBillingAccount.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBillingAccount.Enabled = false;
            this.txtBillingAccount.Location = new System.Drawing.Point(103, 4);
            this.txtBillingAccount.MaxLength = 2;
            this.txtBillingAccount.Name = "txtBillingAccount";
            this.txtBillingAccount.Size = new System.Drawing.Size(112, 20);
            this.txtBillingAccount.TabIndex = 1;
            this.txtBillingAccount.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel11
            // 
            this.radLabel11.Location = new System.Drawing.Point(436, 4);
            this.radLabel11.Name = "radLabel11";
            this.radLabel11.Size = new System.Drawing.Size(51, 18);
            this.radLabel11.TabIndex = 4;
            this.radLabel11.Text = "Invoice #";
            this.radLabel11.ThemeName = "TelerikMetroBlue";
            // 
            // txtInvoiceNo
            // 
            this.txtInvoiceNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtInvoiceNo.Enabled = false;
            this.txtInvoiceNo.Location = new System.Drawing.Point(497, 4);
            this.txtInvoiceNo.MaxLength = 2;
            this.txtInvoiceNo.Name = "txtInvoiceNo";
            this.txtInvoiceNo.ReadOnly = true;
            this.txtInvoiceNo.Size = new System.Drawing.Size(112, 20);
            this.txtInvoiceNo.TabIndex = 5;
            this.txtInvoiceNo.ThemeName = "TelerikMetroBlue";
            // 
            // dataGridView1
            // 
            this.dataGridView1.EnterKeyMode = Telerik.WinControls.UI.RadGridViewEnterKeyMode.EnterMovesToNextCell;
            this.dataGridView1.Location = new System.Drawing.Point(13, 204);
            // 
            // 
            // 
            this.dataGridView1.MasterTemplate.AddNewRowPosition = Telerik.WinControls.UI.SystemRowPosition.Bottom;
            this.dataGridView1.MasterTemplate.AutoSizeColumnsMode = Telerik.WinControls.UI.GridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.MasterTemplate.EnableGrouping = false;
            this.dataGridView1.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.NewRowEnterKeyMode = Telerik.WinControls.UI.RadGridViewNewRowEnterKeyMode.EnterMovesToNextCell;
            this.dataGridView1.Size = new System.Drawing.Size(818, 228);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CreateRow += new Telerik.WinControls.UI.GridViewCreateRowEventHandler(this.dataGridView1_CreateRow);
            this.dataGridView1.UserDeletedRow += new Telerik.WinControls.UI.GridViewRowEventHandler(this.dataGridView1_UserDeletedRow);
            // 
            // chkViaFedex
            // 
            this.chkViaFedex.Location = new System.Drawing.Point(536, 520);
            this.chkViaFedex.Name = "chkViaFedex";
            this.chkViaFedex.Size = new System.Drawing.Size(68, 18);
            this.chkViaFedex.TabIndex = 17;
            this.chkViaFedex.Text = "Via Fedex";
            this.chkViaFedex.ThemeName = "TelerikMetroBlue";
            // 
            // chkSHOverride
            // 
            this.chkSHOverride.Location = new System.Drawing.Point(536, 554);
            this.chkSHOverride.Name = "chkSHOverride";
            this.chkSHOverride.Size = new System.Drawing.Size(90, 18);
            this.chkSHOverride.TabIndex = 18;
            this.chkSHOverride.Text = "S&&H Override";
            this.chkSHOverride.ThemeName = "TelerikMetroBlue";
            this.chkSHOverride.ToggleStateChanged += new Telerik.WinControls.UI.StateChangedEventHandler(this.chkSHOverride_ToggleStateChanged);
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(308, 463);
            this.txtWeight.Mask = "N0";
            this.txtWeight.MaskType = Telerik.WinControls.UI.MaskType.Numeric;
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(100, 20);
            this.txtWeight.TabIndex = 14;
            this.txtWeight.TabStop = false;
            this.txtWeight.Text = "0";
            this.txtWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtWeight.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.txtWeight.ThemeName = "TelerikMetroBlue";
            // 
            // radLabel12
            // 
            this.radLabel12.Location = new System.Drawing.Point(233, 464);
            this.radLabel12.Name = "radLabel12";
            this.radLabel12.Size = new System.Drawing.Size(41, 18);
            this.radLabel12.TabIndex = 13;
            this.radLabel12.Text = "Pk. Wt.";
            this.radLabel12.ThemeName = "TelerikMetroBlue";
            // 
            // frmInvoiceNotFromPO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(842, 620);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.radLabel12);
            this.Controls.Add(this.chkSHOverride);
            this.Controls.Add(this.chkViaFedex);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.radLabel11);
            this.Controls.Add(this.txtInvoiceNo);
            this.Controls.Add(this.radLabel10);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.txtBillingAccount);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.radLabel9);
            this.Controls.Add(this.radLabel8);
            this.Controls.Add(this.radLabel7);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtShippingHandling);
            this.Controls.Add(this.txtOtherCharges);
            this.Controls.Add(this.txtSubTotal);
            this.Controls.Add(this.radGroupBox4);
            this.Controls.Add(this.txtInsuredFor);
            this.Controls.Add(this.radLabel6);
            this.Controls.Add(this.lblCreditLimit);
            this.Controls.Add(this.grpPayterms);
            this.Controls.Add(this.radLabel5);
            this.Controls.Add(this.txtNote);
            this.Controls.Add(this.radLabel4);
            this.Controls.Add(this.grpShipVia);
            this.Controls.Add(this.radGroupBox3);
            this.Controls.Add(this.radLabel3);
            this.Controls.Add(this.radGroupBox2);
            this.Controls.Add(this.radLabel2);
            this.Controls.Add(this.radGroupBox1);
            this.Name = "frmInvoiceNotFromPO";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "Invoice";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmInvoice_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmInvoice_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).EndInit();
            this.radGroupBox1.ResumeLayout(false);
            this.radGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtZip1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCountry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCountry1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblTel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblZip1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtState1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblState1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCity1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCity1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddr12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddr1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAddress1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            this.radGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCountry2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCountry2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtZip2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblZip2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtState2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblState2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCity2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCity2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddr22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAddr2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblAddress2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtName2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblName2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkResidentialAddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).EndInit();
            this.radGroupBox3.ResumeLayout(false);
            this.radGroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPONo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblEstdDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInvoiceDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpShipVia)).EndInit();
            this.grpShipVia.ResumeLayout(false);
            this.grpShipVia.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayLetter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayFirst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoPickup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayPriority)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoDelivery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDatStd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo2Day)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoSaturday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoMail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoExpressSaver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoGround)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPayTerm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblPercent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grpPayterms)).EndInit();
            this.grpPayterms.ResumeLayout(false);
            this.grpPayterms.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkCOD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPayTerm8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTermPercent8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInsuredFor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblCreditLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox4)).EndInit();
            this.radGroupBox4.ResumeLayout(false);
            this.radGroupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoUPSSaver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoEarlyAm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoRegular)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtOtherCharges)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtShippingHandling)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnOK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtBillingAccount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtInvoiceNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkViaFedex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkSHOverride)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox1;
        private Telerik.WinControls.UI.RadTextBox txtZip1;
        private Telerik.WinControls.UI.RadTextBox txtCountry;
        private Telerik.WinControls.UI.RadLabel lblCountry1;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTel;
        private Telerik.WinControls.UI.RadLabel lblTel;
        private Telerik.WinControls.UI.RadLabel lblZip1;
        private Telerik.WinControls.UI.RadTextBox txtState1;
        private Telerik.WinControls.UI.RadLabel lblState1;
        private Telerik.WinControls.UI.RadTextBox txtCity1;
        private Telerik.WinControls.UI.RadLabel lblCity1;
        private Telerik.WinControls.UI.RadTextBox txtAddr12;
        private Telerik.WinControls.UI.RadTextBox txtAddr1;
        private Telerik.WinControls.UI.RadLabel lblAddress1;
        private Telerik.WinControls.UI.RadTextBox txtName;
        private Telerik.WinControls.UI.RadLabel lblName;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private Telerik.WinControls.UI.RadTextBox txtCountry2;
        private Telerik.WinControls.UI.RadLabel lblCountry2;
        private Telerik.WinControls.UI.RadTextBox txtZip2;
        private Telerik.WinControls.UI.RadLabel lblZip2;
        private Telerik.WinControls.UI.RadTextBox txtState2;
        private Telerik.WinControls.UI.RadLabel lblState2;
        private Telerik.WinControls.UI.RadTextBox txtCity2;
        private Telerik.WinControls.UI.RadLabel lblCity2;
        private Telerik.WinControls.UI.RadTextBox txtAddr22;
        private Telerik.WinControls.UI.RadTextBox txtAddr2;
        private Telerik.WinControls.UI.RadLabel lblAddress2;
        private Telerik.WinControls.UI.RadTextBox txtName2;
        private Telerik.WinControls.UI.RadLabel lblName2;
        private Telerik.WinControls.UI.RadCheckBox chkResidentialAddress;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox3;
        private Telerik.WinControls.UI.RadLabel lblEstdDate;
        private Telerik.WinControls.UI.RadDateTimePicker txtInvoiceDate;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadTextBox txtPONo;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadGroupBox grpShipVia;
        private Telerik.WinControls.UI.RadRadioButton rdoNextDayLetter;
        private Telerik.WinControls.UI.RadRadioButton rdoNone;
        private Telerik.WinControls.UI.RadRadioButton rdoNextDayFirst;
        private Telerik.WinControls.UI.RadRadioButton rdoPickup;
        private Telerik.WinControls.UI.RadRadioButton rdoNextDayPriority;
        private Telerik.WinControls.UI.RadRadioButton rdoDelivery;
        private Telerik.WinControls.UI.RadRadioButton rdoNextDatStd;
        private Telerik.WinControls.UI.RadRadioButton rdo2Day;
        private Telerik.WinControls.UI.RadRadioButton rdoSaturday;
        private Telerik.WinControls.UI.RadRadioButton rdoMail;
        private Telerik.WinControls.UI.RadRadioButton rdoExpressSaver;
        private Telerik.WinControls.UI.RadRadioButton rdoGround;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadTextBox txtNote;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadLabel lblPayTerm;
        private Telerik.WinControls.UI.RadMaskedEditBox txtPayTerm1;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTermPercent1;
        private Telerik.WinControls.UI.RadMaskedEditBox txtPayTerm2;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTermPercent2;
        private Telerik.WinControls.UI.RadMaskedEditBox txtPayTerm3;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTermPercent3;
        private Telerik.WinControls.UI.RadMaskedEditBox txtPayTerm4;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTermPercent4;
        private Telerik.WinControls.UI.RadLabel lblPercent;
        private Telerik.WinControls.UI.RadGroupBox grpPayterms;
        private Telerik.WinControls.UI.RadMaskedEditBox txtInsuredFor;
        private Telerik.WinControls.UI.RadLabel lblCreditLimit;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox4;
        private Telerik.WinControls.UI.RadRadioButton rdoUPSSaver;
        private Telerik.WinControls.UI.RadRadioButton rdoEarlyAm;
        private Telerik.WinControls.UI.RadRadioButton rdoRegular;
        private Telerik.WinControls.UI.RadMaskedEditBox txtSubTotal;
        private Telerik.WinControls.UI.RadMaskedEditBox txtOtherCharges;
        private Telerik.WinControls.UI.RadMaskedEditBox txtShippingHandling;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTotal;
        private Telerik.WinControls.UI.RadLabel radLabel7;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadButton btnSave;
        private Telerik.WinControls.UI.RadButton btnCancel;
        private Telerik.WinControls.UI.RadButton btnOK;
        private Telerik.WinControls.UI.RadLabel radLabel10;
        private Telerik.WinControls.UI.RadTextBox txtBillingAccount;
        private Telerik.WinControls.UI.RadLabel radLabel11;
        private Telerik.WinControls.UI.RadTextBox txtInvoiceNo;
        private Telerik.WinControls.UI.RadGridView dataGridView1;
        private Telerik.WinControls.UI.RadCheckBox chkViaFedex;
        private Telerik.WinControls.UI.RadCheckBox chkSHOverride;
        private Telerik.WinControls.UI.RadMaskedEditBox txtWeight;
        private Telerik.WinControls.UI.RadLabel radLabel12;
        private Telerik.WinControls.UI.RadLabel radLabel18;
        private Telerik.WinControls.UI.RadLabel radLabel17;
        private Telerik.WinControls.UI.RadLabel radLabel16;
        private Telerik.WinControls.UI.RadLabel radLabel15;
        private Telerik.WinControls.UI.RadCheckBox chkCOD;
        private Telerik.WinControls.UI.RadLabel radLabel13;
        private Telerik.WinControls.UI.RadLabel radLabel14;
        private Telerik.WinControls.UI.RadLabel radLabel19;
        private Telerik.WinControls.UI.RadLabel radLabel20;
        private Telerik.WinControls.UI.RadLabel radLabel21;
        private Telerik.WinControls.UI.RadMaskedEditBox txtPayTerm5;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTermPercent5;
        private Telerik.WinControls.UI.RadMaskedEditBox txtPayTerm6;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTermPercent6;
        private Telerik.WinControls.UI.RadMaskedEditBox txtPayTerm7;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTermPercent7;
        private Telerik.WinControls.UI.RadMaskedEditBox txtPayTerm8;
        private Telerik.WinControls.UI.RadMaskedEditBox txtTermPercent8;
        private Telerik.WinControls.UI.RadLabel radLabel22;
    }
}
