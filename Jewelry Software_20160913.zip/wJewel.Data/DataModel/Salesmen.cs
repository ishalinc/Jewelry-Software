﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IshalInc.wJewel.Data.DataModel
{
    public class Salesmen
    {
        public string NAME { get; set; }

        public string CODE { get; set; }

        public decimal? TEL { get; set; }

        public string ADDR1 { get; set; }

        public string ADDR2 { get; set; }

        public string ADDR3 { get; set; }

        public string NOTE1 { get; set; }

        public string NOTE2 { get; set; }

        public string NOTE3 { get; set; }

        public decimal? TEL1 { get; set; }

        public decimal? TEL2 { get; set; }

    }



}
