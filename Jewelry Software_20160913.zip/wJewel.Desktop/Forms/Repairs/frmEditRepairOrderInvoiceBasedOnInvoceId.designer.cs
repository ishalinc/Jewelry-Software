﻿namespace IshalInc.wJewel.Desktop.Forms
{
    partial class frmEditRepairOrderInvoiceBasedOnInvoceId
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Telerik.WinControls.UI.TableViewDefinition tableViewDefinition1 = new Telerik.WinControls.UI.TableViewDefinition();
            this.radCheckBox2 = new Telerik.WinControls.UI.RadCheckBox();
            this.rdo2Day = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoNextDayLetter = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoNone = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoNextDayFirst = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoPickup = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoNextDayPriority = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoDelivery = new Telerik.WinControls.UI.RadRadioButton();
            this.radCheckBox4 = new Telerik.WinControls.UI.RadCheckBox();
            this.radGroupBox6 = new Telerik.WinControls.UI.RadGroupBox();
            this.rdoNextDatStd = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoSaturday = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoMail = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoExpressSaver = new Telerik.WinControls.UI.RadRadioButton();
            this.rdoGround = new Telerik.WinControls.UI.RadRadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radGroupBox5 = new Telerik.WinControls.UI.RadGroupBox();
            this.shipbycodcheck = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbycodcash = new Telerik.WinControls.UI.RadRadioButton();
            this.shipbynoncode = new Telerik.WinControls.UI.RadRadioButton();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.radCheckBox1 = new Telerik.WinControls.UI.RadCheckBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.radTextBox11 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox10 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox9 = new Telerik.WinControls.UI.RadTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radCheckBox3 = new Telerik.WinControls.UI.RadCheckBox();
            this.radTextBox8 = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel12 = new Telerik.WinControls.UI.RadLabel();
            this.radTextBox18 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox19 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox16 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox14 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox17 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox15 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox13 = new Telerik.WinControls.UI.RadTextBox();
            this.radTextBox12 = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel13 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel11 = new Telerik.WinControls.UI.RadLabel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.billingaccount = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox3 = new Telerik.WinControls.UI.RadGroupBox();
            this.invno = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel7 = new Telerik.WinControls.UI.RadLabel();
            this.billingcountry = new Telerik.WinControls.UI.RadTextBox();
            this.billingzip = new Telerik.WinControls.UI.RadTextBox();
            this.orderrepairno = new Telerik.WinControls.UI.RadTextBox();
            this.billingstate = new Telerik.WinControls.UI.RadTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.billingcity = new Telerik.WinControls.UI.RadTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.billingaddress2 = new Telerik.WinControls.UI.RadTextBox();
            this.radTexbillingaddress = new Telerik.WinControls.UI.RadTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.repairordernote = new Telerik.WinControls.UI.RadTextBoxControl();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.radGridView1 = new Telerik.WinControls.UI.RadGridView();
            this.radLabel10 = new Telerik.WinControls.UI.RadLabel();
            this.ordshipto = new Telerik.WinControls.UI.RadTextBox();
            this.ordcustcode = new Telerik.WinControls.UI.RadTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ordercountry = new Telerik.WinControls.UI.RadTextBox();
            this.orderzip = new Telerik.WinControls.UI.RadTextBox();
            this.orderstate = new Telerik.WinControls.UI.RadTextBox();
            this.ordercity = new Telerik.WinControls.UI.RadTextBox();
            this.orderadd2 = new Telerik.WinControls.UI.RadTextBox();
            this.orderadd1 = new Telerik.WinControls.UI.RadTextBox();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo2Day)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayLetter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayFirst)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoPickup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayPriority)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoDelivery)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox6)).BeginInit();
            this.radGroupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDatStd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoSaturday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoMail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoExpressSaver)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoGround)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox5)).BeginInit();
            this.radGroupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shipbycodcheck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbycodcash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbynoncode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox9)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingaccount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).BeginInit();
            this.radGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingcountry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderrepairno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingstate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingcity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingaddress2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTexbillingaddress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairordernote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordshipto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordcustcode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordercountry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderzip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderstate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordercity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderadd2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderadd1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radCheckBox2
            // 
            this.radCheckBox2.Location = new System.Drawing.Point(662, 430);
            this.radCheckBox2.Name = "radCheckBox2";
            this.radCheckBox2.Size = new System.Drawing.Size(66, 18);
            this.radCheckBox2.TabIndex = 88;
            this.radCheckBox2.Text = "Bulk Ship";
            // 
            // rdo2Day
            // 
            this.rdo2Day.Location = new System.Drawing.Point(5, 43);
            this.rdo2Day.Name = "rdo2Day";
            this.rdo2Day.Size = new System.Drawing.Size(49, 18);
            this.rdo2Day.TabIndex = 15;
            this.rdo2Day.Text = "2 Day";
            this.rdo2Day.ThemeName = "TelerikMetroBlue";
            // 
            // rdoNextDayLetter
            // 
            this.rdoNextDayLetter.Location = new System.Drawing.Point(200, 7);
            this.rdoNextDayLetter.Name = "rdoNextDayLetter";
            this.rdoNextDayLetter.Size = new System.Drawing.Size(98, 18);
            this.rdoNextDayLetter.TabIndex = 19;
            this.rdoNextDayLetter.Text = "Next Day Letter";
            this.rdoNextDayLetter.ThemeName = "TelerikMetroBlue";
            // 
            // rdoNone
            // 
            this.rdoNone.CheckState = System.Windows.Forms.CheckState.Checked;
            this.rdoNone.Location = new System.Drawing.Point(299, 43);
            this.rdoNone.Name = "rdoNone";
            this.rdoNone.Size = new System.Drawing.Size(48, 18);
            this.rdoNone.TabIndex = 12;
            this.rdoNone.Text = "None";
            this.rdoNone.ThemeName = "TelerikMetroBlue";
            this.rdoNone.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            // 
            // rdoNextDayFirst
            // 
            this.rdoNextDayFirst.Location = new System.Drawing.Point(93, 43);
            this.rdoNextDayFirst.Name = "rdoNextDayFirst";
            this.rdoNextDayFirst.Size = new System.Drawing.Size(90, 18);
            this.rdoNextDayFirst.TabIndex = 18;
            this.rdoNextDayFirst.Text = "Next Day First";
            this.rdoNextDayFirst.ThemeName = "TelerikMetroBlue";
            // 
            // rdoPickup
            // 
            this.rdoPickup.Location = new System.Drawing.Point(299, 25);
            this.rdoPickup.Name = "rdoPickup";
            this.rdoPickup.Size = new System.Drawing.Size(53, 18);
            this.rdoPickup.TabIndex = 23;
            this.rdoPickup.Text = "Pickup";
            this.rdoPickup.ThemeName = "TelerikMetroBlue";
            // 
            // rdoNextDayPriority
            // 
            this.rdoNextDayPriority.Location = new System.Drawing.Point(93, 25);
            this.rdoNextDayPriority.Name = "rdoNextDayPriority";
            this.rdoNextDayPriority.Size = new System.Drawing.Size(105, 18);
            this.rdoNextDayPriority.TabIndex = 17;
            this.rdoNextDayPriority.Text = "Next Day Priority";
            this.rdoNextDayPriority.ThemeName = "TelerikMetroBlue";
            // 
            // rdoDelivery
            // 
            this.rdoDelivery.Location = new System.Drawing.Point(299, 7);
            this.rdoDelivery.Name = "rdoDelivery";
            this.rdoDelivery.Size = new System.Drawing.Size(60, 18);
            this.rdoDelivery.TabIndex = 22;
            this.rdoDelivery.Text = "Delivery";
            this.rdoDelivery.ThemeName = "TelerikMetroBlue";
            // 
            // radCheckBox4
            // 
            this.radCheckBox4.Location = new System.Drawing.Point(99, 147);
            this.radCheckBox4.Name = "radCheckBox4";
            this.radCheckBox4.Size = new System.Drawing.Size(68, 18);
            this.radCheckBox4.TabIndex = 5;
            this.radCheckBox4.Text = "Via Fedex";
            // 
            // radGroupBox6
            // 
            this.radGroupBox6.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.radGroupBox6.Controls.Add(this.rdo2Day);
            this.radGroupBox6.Controls.Add(this.rdoNextDayLetter);
            this.radGroupBox6.Controls.Add(this.rdoNone);
            this.radGroupBox6.Controls.Add(this.rdoNextDayFirst);
            this.radGroupBox6.Controls.Add(this.rdoPickup);
            this.radGroupBox6.Controls.Add(this.rdoNextDayPriority);
            this.radGroupBox6.Controls.Add(this.rdoDelivery);
            this.radGroupBox6.Controls.Add(this.rdoNextDatStd);
            this.radGroupBox6.Controls.Add(this.rdoSaturday);
            this.radGroupBox6.Controls.Add(this.rdoMail);
            this.radGroupBox6.Controls.Add(this.rdoExpressSaver);
            this.radGroupBox6.Controls.Add(this.rdoGround);
            this.radGroupBox6.HeaderText = "";
            this.radGroupBox6.Location = new System.Drawing.Point(6, 29);
            this.radGroupBox6.Name = "radGroupBox6";
            this.radGroupBox6.Size = new System.Drawing.Size(361, 69);
            this.radGroupBox6.TabIndex = 3;
            // 
            // rdoNextDatStd
            // 
            this.rdoNextDatStd.Location = new System.Drawing.Point(93, 7);
            this.rdoNextDatStd.Name = "rdoNextDatStd";
            this.rdoNextDatStd.Size = new System.Drawing.Size(86, 18);
            this.rdoNextDatStd.TabIndex = 16;
            this.rdoNextDatStd.Text = "Next Day Std";
            this.rdoNextDatStd.ThemeName = "TelerikMetroBlue";
            // 
            // rdoSaturday
            // 
            this.rdoSaturday.Location = new System.Drawing.Point(200, 25);
            this.rdoSaturday.Name = "rdoSaturday";
            this.rdoSaturday.Size = new System.Drawing.Size(64, 18);
            this.rdoSaturday.TabIndex = 20;
            this.rdoSaturday.Text = "Saturday";
            this.rdoSaturday.ThemeName = "TelerikMetroBlue";
            // 
            // rdoMail
            // 
            this.rdoMail.Location = new System.Drawing.Point(200, 43);
            this.rdoMail.Name = "rdoMail";
            this.rdoMail.Size = new System.Drawing.Size(42, 18);
            this.rdoMail.TabIndex = 21;
            this.rdoMail.Text = "Mail";
            this.rdoMail.ThemeName = "TelerikMetroBlue";
            // 
            // rdoExpressSaver
            // 
            this.rdoExpressSaver.Location = new System.Drawing.Point(5, 25);
            this.rdoExpressSaver.Name = "rdoExpressSaver";
            this.rdoExpressSaver.Size = new System.Drawing.Size(87, 18);
            this.rdoExpressSaver.TabIndex = 14;
            this.rdoExpressSaver.Text = "Express Saver";
            this.rdoExpressSaver.ThemeName = "TelerikMetroBlue";
            // 
            // rdoGround
            // 
            this.rdoGround.Location = new System.Drawing.Point(5, 7);
            this.rdoGround.Name = "rdoGround";
            this.rdoGround.Size = new System.Drawing.Size(58, 18);
            this.rdoGround.TabIndex = 13;
            this.rdoGround.Text = "Ground";
            this.rdoGround.ThemeName = "TelerikMetroBlue";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radCheckBox4);
            this.groupBox2.Controls.Add(this.radGroupBox6);
            this.groupBox2.Controls.Add(this.radGroupBox5);
            this.groupBox2.Controls.Add(this.radLabel9);
            this.groupBox2.Controls.Add(this.radCheckBox1);
            this.groupBox2.Location = new System.Drawing.Point(169, 463);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(373, 175);
            this.groupBox2.TabIndex = 90;
            this.groupBox2.TabStop = false;
            // 
            // radGroupBox5
            // 
            this.radGroupBox5.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.radGroupBox5.Controls.Add(this.shipbycodcheck);
            this.radGroupBox5.Controls.Add(this.shipbycodcash);
            this.radGroupBox5.Controls.Add(this.shipbynoncode);
            this.radGroupBox5.HeaderText = "";
            this.radGroupBox5.Location = new System.Drawing.Point(6, 106);
            this.radGroupBox5.Name = "radGroupBox5";
            this.radGroupBox5.Size = new System.Drawing.Size(361, 31);
            this.radGroupBox5.TabIndex = 1;
            // 
            // shipbycodcheck
            // 
            this.shipbycodcheck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(219)))), ((int)(((byte)(255)))));
            this.shipbycodcheck.Location = new System.Drawing.Point(200, 4);
            this.shipbycodcheck.Name = "shipbycodcheck";
            this.shipbycodcheck.Size = new System.Drawing.Size(73, 18);
            this.shipbycodcheck.TabIndex = 21;
            this.shipbycodcheck.TabStop = false;
            this.shipbycodcheck.Text = "Cod-check";
            // 
            // shipbycodcash
            // 
            this.shipbycodcash.Location = new System.Drawing.Point(93, 4);
            this.shipbycodcash.Name = "shipbycodcash";
            this.shipbycodcash.Size = new System.Drawing.Size(67, 18);
            this.shipbycodcash.TabIndex = 20;
            this.shipbycodcash.TabStop = false;
            this.shipbycodcash.Text = "Cod-cash";
            // 
            // shipbynoncode
            // 
            this.shipbynoncode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.shipbynoncode.Location = new System.Drawing.Point(8, 4);
            this.shipbynoncode.Name = "shipbynoncode";
            this.shipbynoncode.Size = new System.Drawing.Size(65, 18);
            this.shipbynoncode.TabIndex = 1;
            this.shipbynoncode.TabStop = false;
            this.shipbynoncode.Text = "Non-cod";
            this.shipbynoncode.ToggleState = Telerik.WinControls.Enumerations.ToggleState.On;
            // 
            // radLabel9
            // 
            this.radLabel9.AutoSize = false;
            this.radLabel9.BackColor = System.Drawing.Color.YellowGreen;
            this.radLabel9.BorderVisible = true;
            this.radLabel9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel9.ForeColor = System.Drawing.Color.White;
            this.radLabel9.Location = new System.Drawing.Point(1, 9);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(370, 18);
            this.radLabel9.TabIndex = 0;
            this.radLabel9.Text = "Shipping Methods";
            this.radLabel9.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radCheckBox1
            // 
            this.radCheckBox1.Location = new System.Drawing.Point(14, 146);
            this.radCheckBox1.Name = "radCheckBox1";
            this.radCheckBox1.Size = new System.Drawing.Size(75, 18);
            this.radCheckBox1.TabIndex = 4;
            this.radCheckBox1.Text = "Residential";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(6, 82);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(52, 13);
            this.linkLabel1.TabIndex = 79;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Calc SnH";
            // 
            // radTextBox11
            // 
            this.radTextBox11.Location = new System.Drawing.Point(80, 121);
            this.radTextBox11.Name = "radTextBox11";
            this.radTextBox11.ReadOnly = true;
            this.radTextBox11.Size = new System.Drawing.Size(99, 20);
            this.radTextBox11.TabIndex = 8;
            // 
            // radTextBox10
            // 
            this.radTextBox10.Location = new System.Drawing.Point(80, 78);
            this.radTextBox10.Name = "radTextBox10";
            this.radTextBox10.ReadOnly = true;
            this.radTextBox10.Size = new System.Drawing.Size(99, 20);
            this.radTextBox10.TabIndex = 5;
            this.radTextBox10.Text = "0.00";
            // 
            // radTextBox9
            // 
            this.radTextBox9.Location = new System.Drawing.Point(80, 54);
            this.radTextBox9.Name = "radTextBox9";
            this.radTextBox9.Size = new System.Drawing.Size(99, 20);
            this.radTextBox9.TabIndex = 3;
            this.radTextBox9.Text = "0.00";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Controls.Add(this.radTextBox11);
            this.groupBox1.Controls.Add(this.radTextBox10);
            this.groupBox1.Controls.Add(this.radTextBox9);
            this.groupBox1.Controls.Add(this.radCheckBox3);
            this.groupBox1.Controls.Add(this.radTextBox8);
            this.groupBox1.Controls.Add(this.radLabel8);
            this.groupBox1.Controls.Add(this.radLabel6);
            this.groupBox1.Controls.Add(this.radLabel5);
            this.groupBox1.Controls.Add(this.radLabel2);
            this.groupBox1.Location = new System.Drawing.Point(546, 463);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(188, 145);
            this.groupBox1.TabIndex = 91;
            this.groupBox1.TabStop = false;
            // 
            // radCheckBox3
            // 
            this.radCheckBox3.Location = new System.Drawing.Point(80, 104);
            this.radCheckBox3.Name = "radCheckBox3";
            this.radCheckBox3.Size = new System.Drawing.Size(85, 18);
            this.radCheckBox3.TabIndex = 6;
            this.radCheckBox3.Text = "Snh Override";
            // 
            // radTextBox8
            // 
            this.radTextBox8.Location = new System.Drawing.Point(80, 32);
            this.radTextBox8.Name = "radTextBox8";
            this.radTextBox8.ReadOnly = true;
            this.radTextBox8.Size = new System.Drawing.Size(99, 20);
            this.radTextBox8.TabIndex = 1;
            this.radTextBox8.Text = "0";
            // 
            // radLabel8
            // 
            this.radLabel8.Location = new System.Drawing.Point(6, 121);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(31, 18);
            this.radLabel8.TabIndex = 7;
            this.radLabel8.Text = "Total";
            // 
            // radLabel6
            // 
            this.radLabel6.Location = new System.Drawing.Point(6, 57);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(56, 18);
            this.radLabel6.TabIndex = 2;
            this.radLabel6.Text = "Insure For";
            // 
            // radLabel5
            // 
            this.radLabel5.Location = new System.Drawing.Point(6, 33);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(48, 18);
            this.radLabel5.TabIndex = 0;
            this.radLabel5.Text = "Subtotal";
            // 
            // radLabel2
            // 
            this.radLabel2.AutoSize = false;
            this.radLabel2.BackColor = System.Drawing.Color.YellowGreen;
            this.radLabel2.BorderVisible = true;
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel2.ForeColor = System.Drawing.Color.White;
            this.radLabel2.Location = new System.Drawing.Point(0, 9);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(188, 18);
            this.radLabel2.TabIndex = 78;
            this.radLabel2.Text = "Invoice Total";
            this.radLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radLabel12
            // 
            this.radLabel12.Location = new System.Drawing.Point(19, 36);
            this.radLabel12.Name = "radLabel12";
            this.radLabel12.Size = new System.Drawing.Size(30, 18);
            this.radLabel12.TabIndex = 3;
            this.radLabel12.Text = "Days";
            // 
            // radTextBox18
            // 
            this.radTextBox18.Location = new System.Drawing.Point(86, 146);
            this.radTextBox18.Name = "radTextBox18";
            this.radTextBox18.Size = new System.Drawing.Size(54, 20);
            this.radTextBox18.TabIndex = 10;
            this.radTextBox18.Text = "0";
            // 
            // radTextBox19
            // 
            this.radTextBox19.Location = new System.Drawing.Point(6, 143);
            this.radTextBox19.Name = "radTextBox19";
            this.radTextBox19.Size = new System.Drawing.Size(59, 20);
            this.radTextBox19.TabIndex = 10;
            this.radTextBox19.Text = "0";
            // 
            // radTextBox16
            // 
            this.radTextBox16.Location = new System.Drawing.Point(86, 120);
            this.radTextBox16.Name = "radTextBox16";
            this.radTextBox16.Size = new System.Drawing.Size(54, 20);
            this.radTextBox16.TabIndex = 10;
            this.radTextBox16.Text = "0";
            // 
            // radTextBox14
            // 
            this.radTextBox14.Location = new System.Drawing.Point(86, 94);
            this.radTextBox14.Name = "radTextBox14";
            this.radTextBox14.Size = new System.Drawing.Size(54, 20);
            this.radTextBox14.TabIndex = 8;
            this.radTextBox14.Text = "0";
            // 
            // radTextBox17
            // 
            this.radTextBox17.Location = new System.Drawing.Point(7, 117);
            this.radTextBox17.Name = "radTextBox17";
            this.radTextBox17.Size = new System.Drawing.Size(58, 20);
            this.radTextBox17.TabIndex = 9;
            this.radTextBox17.Text = "0";
            // 
            // radTextBox15
            // 
            this.radTextBox15.Location = new System.Drawing.Point(7, 91);
            this.radTextBox15.Name = "radTextBox15";
            this.radTextBox15.Size = new System.Drawing.Size(58, 20);
            this.radTextBox15.TabIndex = 7;
            this.radTextBox15.Text = "0";
            // 
            // radTextBox13
            // 
            this.radTextBox13.Location = new System.Drawing.Point(87, 68);
            this.radTextBox13.Name = "radTextBox13";
            this.radTextBox13.Size = new System.Drawing.Size(53, 20);
            this.radTextBox13.TabIndex = 6;
            this.radTextBox13.Text = "100";
            // 
            // radTextBox12
            // 
            this.radTextBox12.Location = new System.Drawing.Point(7, 65);
            this.radTextBox12.Name = "radTextBox12";
            this.radTextBox12.Size = new System.Drawing.Size(58, 20);
            this.radTextBox12.TabIndex = 5;
            this.radTextBox12.Text = "30";
            // 
            // radLabel13
            // 
            this.radLabel13.Location = new System.Drawing.Point(109, 36);
            this.radLabel13.Name = "radLabel13";
            this.radLabel13.Size = new System.Drawing.Size(15, 18);
            this.radLabel13.TabIndex = 4;
            this.radLabel13.Text = "%";
            // 
            // radLabel11
            // 
            this.radLabel11.AutoSize = false;
            this.radLabel11.BackColor = System.Drawing.Color.YellowGreen;
            this.radLabel11.BorderVisible = true;
            this.radLabel11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel11.ForeColor = System.Drawing.Color.White;
            this.radLabel11.Location = new System.Drawing.Point(0, 9);
            this.radLabel11.Name = "radLabel11";
            this.radLabel11.Size = new System.Drawing.Size(189, 18);
            this.radLabel11.TabIndex = 2;
            this.radLabel11.Text = "Payment Terms";
            this.radLabel11.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radTextBox18);
            this.groupBox3.Controls.Add(this.radTextBox19);
            this.groupBox3.Controls.Add(this.radTextBox16);
            this.groupBox3.Controls.Add(this.radTextBox14);
            this.groupBox3.Controls.Add(this.radTextBox17);
            this.groupBox3.Controls.Add(this.radTextBox15);
            this.groupBox3.Controls.Add(this.radTextBox13);
            this.groupBox3.Controls.Add(this.radTextBox12);
            this.groupBox3.Controls.Add(this.radLabel13);
            this.groupBox3.Controls.Add(this.radLabel12);
            this.groupBox3.Controls.Add(this.radLabel11);
            this.groupBox3.Location = new System.Drawing.Point(12, 463);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(151, 175);
            this.groupBox3.TabIndex = 89;
            this.groupBox3.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Code";
            // 
            // radLabel4
            // 
            this.radLabel4.Location = new System.Drawing.Point(12, 56);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(46, 18);
            this.radLabel4.TabIndex = 22;
            this.radLabel4.Text = "Address";
            // 
            // billingaccount
            // 
            this.billingaccount.Location = new System.Drawing.Point(98, 33);
            this.billingaccount.Name = "billingaccount";
            this.billingaccount.Size = new System.Drawing.Size(228, 20);
            this.billingaccount.TabIndex = 13;
            // 
            // radLabel1
            // 
            this.radLabel1.AutoSize = false;
            this.radLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.radLabel1.BorderVisible = true;
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel1.ForeColor = System.Drawing.Color.White;
            this.radLabel1.Location = new System.Drawing.Point(381, 12);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(355, 18);
            this.radLabel1.TabIndex = 84;
            this.radLabel1.Text = "Billing Details";
            this.radLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radGroupBox3
            // 
            this.radGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox3.Controls.Add(this.invno);
            this.radGroupBox3.Controls.Add(this.radLabel7);
            this.radGroupBox3.Controls.Add(this.radLabel4);
            this.radGroupBox3.Controls.Add(this.billingaccount);
            this.radGroupBox3.Controls.Add(this.billingcountry);
            this.radGroupBox3.Controls.Add(this.billingzip);
            this.radGroupBox3.Controls.Add(this.orderrepairno);
            this.radGroupBox3.Controls.Add(this.billingstate);
            this.radGroupBox3.Controls.Add(this.label8);
            this.radGroupBox3.Controls.Add(this.billingcity);
            this.radGroupBox3.Controls.Add(this.label7);
            this.radGroupBox3.Controls.Add(this.billingaddress2);
            this.radGroupBox3.Controls.Add(this.radTexbillingaddress);
            this.radGroupBox3.Controls.Add(this.label13);
            this.radGroupBox3.Controls.Add(this.label9);
            this.radGroupBox3.Controls.Add(this.label12);
            this.radGroupBox3.Controls.Add(this.label10);
            this.radGroupBox3.Controls.Add(this.label11);
            this.radGroupBox3.HeaderText = "";
            this.radGroupBox3.Location = new System.Drawing.Point(381, 24);
            this.radGroupBox3.Name = "radGroupBox3";
            this.radGroupBox3.Size = new System.Drawing.Size(355, 175);
            this.radGroupBox3.TabIndex = 85;
            // 
            // invno
            // 
            this.invno.Location = new System.Drawing.Point(245, 12);
            this.invno.Name = "invno";
            this.invno.ReadOnly = true;
            this.invno.Size = new System.Drawing.Size(81, 20);
            this.invno.TabIndex = 25;
            // 
            // radLabel7
            // 
            this.radLabel7.Location = new System.Drawing.Point(198, 12);
            this.radLabel7.Name = "radLabel7";
            this.radLabel7.Size = new System.Drawing.Size(42, 18);
            this.radLabel7.TabIndex = 24;
            this.radLabel7.Text = "Invoice";
            // 
            // billingcountry
            // 
            this.billingcountry.Location = new System.Drawing.Point(98, 148);
            this.billingcountry.Name = "billingcountry";
            this.billingcountry.Size = new System.Drawing.Size(228, 20);
            this.billingcountry.TabIndex = 21;
            // 
            // billingzip
            // 
            this.billingzip.Location = new System.Drawing.Point(198, 123);
            this.billingzip.MaxLength = 10;
            this.billingzip.Name = "billingzip";
            this.billingzip.Size = new System.Drawing.Size(128, 20);
            this.billingzip.TabIndex = 20;
            // 
            // orderrepairno
            // 
            this.orderrepairno.Location = new System.Drawing.Point(98, 11);
            this.orderrepairno.Name = "orderrepairno";
            this.orderrepairno.ReadOnly = true;
            this.orderrepairno.Size = new System.Drawing.Size(94, 20);
            this.orderrepairno.TabIndex = 9;
            // 
            // billingstate
            // 
            this.billingstate.Location = new System.Drawing.Point(98, 123);
            this.billingstate.MaxLength = 2;
            this.billingstate.Name = "billingstate";
            this.billingstate.Size = new System.Drawing.Size(65, 20);
            this.billingstate.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Billing Account";
            // 
            // billingcity
            // 
            this.billingcity.Location = new System.Drawing.Point(98, 101);
            this.billingcity.Name = "billingcity";
            this.billingcity.Size = new System.Drawing.Size(228, 20);
            this.billingcity.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Repair No.";
            // 
            // billingaddress2
            // 
            this.billingaddress2.Location = new System.Drawing.Point(98, 78);
            this.billingaddress2.Name = "billingaddress2";
            this.billingaddress2.Size = new System.Drawing.Size(228, 20);
            this.billingaddress2.TabIndex = 14;
            // 
            // radTexbillingaddress
            // 
            this.radTexbillingaddress.Location = new System.Drawing.Point(98, 56);
            this.radTexbillingaddress.Name = "radTexbillingaddress";
            this.radTexbillingaddress.Size = new System.Drawing.Size(228, 20);
            this.radTexbillingaddress.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(0, 13);
            this.label13.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 152);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Country";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 106);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(26, 13);
            this.label12.TabIndex = 13;
            this.label12.Text = "City";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(173, 128);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(23, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Zip";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 128);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 15;
            this.label11.Text = "State";
            // 
            // radButton2
            // 
            this.radButton2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.radButton2.Image = global::IshalInc.wJewel.Desktop.Properties.Resources.cancel;
            this.radButton2.Location = new System.Drawing.Point(652, 614);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(68, 24);
            this.radButton2.TabIndex = 93;
            this.radButton2.Text = "Cancel";
            this.radButton2.Click += new System.EventHandler(this.radButton2_Click);
            // 
            // radButton1
            // 
            this.radButton1.Image = global::IshalInc.wJewel.Desktop.Properties.Resources.OK;
            this.radButton1.Location = new System.Drawing.Point(568, 614);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(66, 24);
            this.radButton1.TabIndex = 92;
            this.radButton1.Text = "OK";
            this.radButton1.Click += new System.EventHandler(this.radButton1_Click);
            // 
            // repairordernote
            // 
            this.repairordernote.Location = new System.Drawing.Point(69, 430);
            this.repairordernote.Name = "repairordernote";
            this.repairordernote.Size = new System.Drawing.Size(587, 27);
            this.repairordernote.TabIndex = 87;
            // 
            // radLabel3
            // 
            this.radLabel3.Location = new System.Drawing.Point(12, 424);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(31, 18);
            this.radLabel3.TabIndex = 94;
            this.radLabel3.Text = "Note";
            // 
            // radGridView1
            // 
            this.radGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.radGridView1.Location = new System.Drawing.Point(11, 205);
            // 
            // 
            // 
            this.radGridView1.MasterTemplate.ViewDefinition = tableViewDefinition1;
            this.radGridView1.Name = "radGridView1";
            this.radGridView1.Size = new System.Drawing.Size(723, 213);
            this.radGridView1.TabIndex = 86;
            this.radGridView1.TabStop = false;
            this.radGridView1.Text = "radGridView1";
            this.radGridView1.CellValueChanged += new Telerik.WinControls.UI.GridViewCellEventHandler(this.radGridView1_CellValueChanged);
            // 
            // radLabel10
            // 
            this.radLabel10.AutoSize = false;
            this.radLabel10.BackColor = System.Drawing.Color.RoyalBlue;
            this.radLabel10.BorderVisible = true;
            this.radLabel10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel10.ForeColor = System.Drawing.Color.White;
            this.radLabel10.Location = new System.Drawing.Point(12, 12);
            this.radLabel10.Name = "radLabel10";
            this.radLabel10.Size = new System.Drawing.Size(335, 18);
            this.radLabel10.TabIndex = 82;
            this.radLabel10.Text = "Customer Details";
            this.radLabel10.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ordshipto
            // 
            this.ordshipto.Location = new System.Drawing.Point(110, 33);
            this.ordshipto.Name = "ordshipto";
            this.ordshipto.Size = new System.Drawing.Size(200, 20);
            this.ordshipto.TabIndex = 2;
            // 
            // ordcustcode
            // 
            this.ordcustcode.Location = new System.Drawing.Point(110, 11);
            this.ordcustcode.Name = "ordcustcode";
            this.ordcustcode.ReadOnly = true;
            this.ordcustcode.Size = new System.Drawing.Size(200, 20);
            this.ordcustcode.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 152);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Country";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(190, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Zip";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "State";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "City";
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(21, 60);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(48, 13);
            this.Address.TabIndex = 2;
            this.Address.Text = "Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ship To";
            // 
            // ordercountry
            // 
            this.ordercountry.Location = new System.Drawing.Point(110, 148);
            this.ordercountry.Name = "ordercountry";
            this.ordercountry.Size = new System.Drawing.Size(200, 20);
            this.ordercountry.TabIndex = 8;
            // 
            // orderzip
            // 
            this.orderzip.Location = new System.Drawing.Point(210, 126);
            this.orderzip.MaxLength = 5;
            this.orderzip.Name = "orderzip";
            this.orderzip.Size = new System.Drawing.Size(100, 20);
            this.orderzip.TabIndex = 7;
            // 
            // orderstate
            // 
            this.orderstate.Location = new System.Drawing.Point(110, 126);
            this.orderstate.MaxLength = 2;
            this.orderstate.Name = "orderstate";
            this.orderstate.Size = new System.Drawing.Size(65, 20);
            this.orderstate.TabIndex = 6;
            // 
            // ordercity
            // 
            this.ordercity.Location = new System.Drawing.Point(110, 104);
            this.ordercity.Name = "ordercity";
            this.ordercity.Size = new System.Drawing.Size(200, 20);
            this.ordercity.TabIndex = 5;
            // 
            // orderadd2
            // 
            this.orderadd2.Location = new System.Drawing.Point(110, 81);
            this.orderadd2.Name = "orderadd2";
            this.orderadd2.Size = new System.Drawing.Size(200, 20);
            this.orderadd2.TabIndex = 4;
            // 
            // orderadd1
            // 
            this.orderadd1.Location = new System.Drawing.Point(110, 56);
            this.orderadd1.Name = "orderadd1";
            this.orderadd1.Size = new System.Drawing.Size(200, 20);
            this.orderadd1.TabIndex = 3;
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.Controls.Add(this.ordercountry);
            this.radGroupBox2.Controls.Add(this.orderzip);
            this.radGroupBox2.Controls.Add(this.orderstate);
            this.radGroupBox2.Controls.Add(this.ordercity);
            this.radGroupBox2.Controls.Add(this.orderadd2);
            this.radGroupBox2.Controls.Add(this.orderadd1);
            this.radGroupBox2.Controls.Add(this.ordshipto);
            this.radGroupBox2.Controls.Add(this.ordcustcode);
            this.radGroupBox2.Controls.Add(this.label6);
            this.radGroupBox2.Controls.Add(this.label5);
            this.radGroupBox2.Controls.Add(this.label4);
            this.radGroupBox2.Controls.Add(this.label3);
            this.radGroupBox2.Controls.Add(this.Address);
            this.radGroupBox2.Controls.Add(this.label2);
            this.radGroupBox2.Controls.Add(this.label1);
            this.radGroupBox2.HeaderText = "";
            this.radGroupBox2.Location = new System.Drawing.Point(11, 24);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(335, 175);
            this.radGroupBox2.TabIndex = 83;
            // 
            // frmEditRepairOrderInvoiceBasedOnInvoceId
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.radButton2;
            this.ClientSize = new System.Drawing.Size(748, 657);
            this.Controls.Add(this.radCheckBox2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.radLabel1);
            this.Controls.Add(this.radGroupBox3);
            this.Controls.Add(this.radButton2);
            this.Controls.Add(this.radButton1);
            this.Controls.Add(this.repairordernote);
            this.Controls.Add(this.radLabel3);
            this.Controls.Add(this.radGridView1);
            this.Controls.Add(this.radLabel10);
            this.Controls.Add(this.radGroupBox2);
            this.Name = "frmEditRepairOrderInvoiceBasedOnInvoceId";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "frmEditRepairOrderInvoiceBasedOnInvoceId";
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdo2Day)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayLetter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayFirst)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoPickup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDayPriority)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoDelivery)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox6)).EndInit();
            this.radGroupBox6.ResumeLayout(false);
            this.radGroupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rdoNextDatStd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoSaturday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoMail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoExpressSaver)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rdoGround)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox5)).EndInit();
            this.radGroupBox5.ResumeLayout(false);
            this.radGroupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shipbycodcheck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbycodcash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shipbynoncode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox9)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radCheckBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTextBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingaccount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).EndInit();
            this.radGroupBox3.ResumeLayout(false);
            this.radGroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.invno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingcountry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderrepairno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingstate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingcity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.billingaddress2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radTexbillingaddress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairordernote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1.MasterTemplate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordshipto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordcustcode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordercountry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderzip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderstate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordercity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderadd2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderadd1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            this.radGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Telerik.WinControls.UI.RadCheckBox radCheckBox2;
        private Telerik.WinControls.UI.RadRadioButton rdo2Day;
        private Telerik.WinControls.UI.RadRadioButton rdoNextDayLetter;
        private Telerik.WinControls.UI.RadRadioButton rdoNone;
        private Telerik.WinControls.UI.RadRadioButton rdoNextDayFirst;
        private Telerik.WinControls.UI.RadRadioButton rdoPickup;
        private Telerik.WinControls.UI.RadRadioButton rdoNextDayPriority;
        private Telerik.WinControls.UI.RadRadioButton rdoDelivery;
        private Telerik.WinControls.UI.RadCheckBox radCheckBox4;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox6;
        private Telerik.WinControls.UI.RadRadioButton rdoNextDatStd;
        private Telerik.WinControls.UI.RadRadioButton rdoSaturday;
        private Telerik.WinControls.UI.RadRadioButton rdoMail;
        private Telerik.WinControls.UI.RadRadioButton rdoExpressSaver;
        private Telerik.WinControls.UI.RadRadioButton rdoGround;
        private System.Windows.Forms.GroupBox groupBox2;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox5;
        private Telerik.WinControls.UI.RadRadioButton shipbycodcheck;
        private Telerik.WinControls.UI.RadRadioButton shipbycodcash;
        private Telerik.WinControls.UI.RadRadioButton shipbynoncode;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadCheckBox radCheckBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private Telerik.WinControls.UI.RadTextBox radTextBox11;
        private Telerik.WinControls.UI.RadTextBox radTextBox10;
        private Telerik.WinControls.UI.RadTextBox radTextBox9;
        private System.Windows.Forms.GroupBox groupBox1;
        private Telerik.WinControls.UI.RadCheckBox radCheckBox3;
        private Telerik.WinControls.UI.RadTextBox radTextBox8;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadLabel radLabel12;
        private Telerik.WinControls.UI.RadTextBox radTextBox18;
        private Telerik.WinControls.UI.RadTextBox radTextBox19;
        private Telerik.WinControls.UI.RadTextBox radTextBox16;
        private Telerik.WinControls.UI.RadTextBox radTextBox14;
        private Telerik.WinControls.UI.RadTextBox radTextBox17;
        private Telerik.WinControls.UI.RadTextBox radTextBox15;
        private Telerik.WinControls.UI.RadTextBox radTextBox13;
        private Telerik.WinControls.UI.RadTextBox radTextBox12;
        private Telerik.WinControls.UI.RadLabel radLabel13;
        private Telerik.WinControls.UI.RadLabel radLabel11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label1;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadTextBox billingaccount;
        private Telerik.WinControls.UI.RadLabel radLabel1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox3;
        private Telerik.WinControls.UI.RadTextBox billingcountry;
        private Telerik.WinControls.UI.RadTextBox billingzip;
        private Telerik.WinControls.UI.RadTextBox orderrepairno;
        private Telerik.WinControls.UI.RadTextBox billingstate;
        private System.Windows.Forms.Label label8;
        private Telerik.WinControls.UI.RadTextBox billingcity;
        private System.Windows.Forms.Label label7;
        private Telerik.WinControls.UI.RadTextBox billingaddress2;
        private Telerik.WinControls.UI.RadTextBox radTexbillingaddress;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.UI.RadTextBoxControl repairordernote;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadGridView radGridView1;
        private Telerik.WinControls.UI.RadLabel radLabel10;
        private Telerik.WinControls.UI.RadTextBox ordshipto;
        private Telerik.WinControls.UI.RadTextBox ordcustcode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label label2;
        private Telerik.WinControls.UI.RadTextBox ordercountry;
        private Telerik.WinControls.UI.RadTextBox orderzip;
        private Telerik.WinControls.UI.RadTextBox orderstate;
        private Telerik.WinControls.UI.RadTextBox ordercity;
        private Telerik.WinControls.UI.RadTextBox orderadd2;
        private Telerik.WinControls.UI.RadTextBox orderadd1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private Telerik.WinControls.UI.RadTextBox invno;
        private Telerik.WinControls.UI.RadLabel radLabel7;
    }
}
