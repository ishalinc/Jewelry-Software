﻿namespace IshalInc.wJewel.Desktop.Forms
{
    partial class frmRepairOrdersReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radButton2 = new Telerik.WinControls.UI.RadButton();
            this.radButton1 = new Telerik.WinControls.UI.RadButton();
            this.radGroupBox3 = new Telerik.WinControls.UI.RadGroupBox();
            this.print = new Telerik.WinControls.UI.RadRadioButton();
            this.email = new Telerik.WinControls.UI.RadRadioButton();
            this.preview = new Telerik.WinControls.UI.RadRadioButton();
            this.radGroupBox2 = new Telerik.WinControls.UI.RadGroupBox();
            this.todate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.fromdate = new Telerik.WinControls.UI.RadDateTimePicker();
            this.radLabel8 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel19 = new Telerik.WinControls.UI.RadLabel();
            this.fromcustomercode = new Telerik.WinControls.UI.RadTextBox();
            this.torepairorderno = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel9 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel18 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel10 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel17 = new Telerik.WinControls.UI.RadLabel();
            this.tocustomercode = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel16 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel11 = new Telerik.WinControls.UI.RadLabel();
            this.fromrepairorderno = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel12 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel15 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel13 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel14 = new Telerik.WinControls.UI.RadLabel();
            this.openordersonly = new Telerik.WinControls.UI.RadCheckBox();
            this.sortbystyleno = new Telerik.WinControls.UI.RadCheckBox();
            this.radLabel2 = new Telerik.WinControls.UI.RadLabel();
            this.radGroupBox1 = new Telerik.WinControls.UI.RadGroupBox();
            this.radLabel6 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel21 = new Telerik.WinControls.UI.RadLabel();
            this.customerrepairnumber = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel20 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel3 = new Telerik.WinControls.UI.RadLabel();
            this.repairnumber = new Telerik.WinControls.UI.RadTextBox();
            this.lblLeaveBlank1 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel4 = new Telerik.WinControls.UI.RadLabel();
            this.customercode = new Telerik.WinControls.UI.RadTextBox();
            this.radLabel5 = new Telerik.WinControls.UI.RadLabel();
            this.radLabel1 = new Telerik.WinControls.UI.RadLabel();
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).BeginInit();
            this.radGroupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.print)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.email)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.preview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).BeginInit();
            this.radGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.todate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fromdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fromcustomercode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.torepairorderno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tocustomercode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fromrepairorderno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.openordersonly)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sortbystyleno)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).BeginInit();
            this.radGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerrepairnumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairnumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblLeaveBlank1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customercode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            this.SuspendLayout();
            // 
            // radButton2
            // 
            this.radButton2.Image = global::IshalInc.wJewel.Desktop.Properties.Resources.cancel;
            this.radButton2.Location = new System.Drawing.Point(395, 440);
            this.radButton2.Name = "radButton2";
            this.radButton2.Size = new System.Drawing.Size(79, 24);
            this.radButton2.TabIndex = 6;
            this.radButton2.Text = "Cancel";
            this.radButton2.Click += new System.EventHandler(this.radButton2_Click);
            // 
            // radButton1
            // 
            this.radButton1.Image = global::IshalInc.wJewel.Desktop.Properties.Resources.OK;
            this.radButton1.Location = new System.Drawing.Point(287, 440);
            this.radButton1.Name = "radButton1";
            this.radButton1.Size = new System.Drawing.Size(90, 24);
            this.radButton1.TabIndex = 5;
            this.radButton1.Text = "OK";
            this.radButton1.Click += new System.EventHandler(this.radButton1_Click);
            // 
            // radGroupBox3
            // 
            this.radGroupBox3.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox3.Controls.Add(this.print);
            this.radGroupBox3.Controls.Add(this.email);
            this.radGroupBox3.Controls.Add(this.preview);
            this.radGroupBox3.HeaderText = "";
            this.radGroupBox3.Location = new System.Drawing.Point(12, 428);
            this.radGroupBox3.Name = "radGroupBox3";
            this.radGroupBox3.Size = new System.Drawing.Size(269, 40);
            this.radGroupBox3.TabIndex = 4;
            // 
            // print
            // 
            this.print.Location = new System.Drawing.Point(209, 15);
            this.print.Name = "print";
            this.print.Size = new System.Drawing.Size(43, 18);
            this.print.TabIndex = 14;
            this.print.Text = "Print";
            // 
            // email
            // 
            this.email.Location = new System.Drawing.Point(109, 15);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(47, 18);
            this.email.TabIndex = 13;
            this.email.Text = "Email";
            // 
            // preview
            // 
            this.preview.Location = new System.Drawing.Point(14, 15);
            this.preview.Name = "preview";
            this.preview.Size = new System.Drawing.Size(59, 18);
            this.preview.TabIndex = 12;
            this.preview.Text = "Preview";
            // 
            // radGroupBox2
            // 
            this.radGroupBox2.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox2.Controls.Add(this.todate);
            this.radGroupBox2.Controls.Add(this.fromdate);
            this.radGroupBox2.Controls.Add(this.radLabel8);
            this.radGroupBox2.Controls.Add(this.radLabel19);
            this.radGroupBox2.Controls.Add(this.fromcustomercode);
            this.radGroupBox2.Controls.Add(this.torepairorderno);
            this.radGroupBox2.Controls.Add(this.radLabel9);
            this.radGroupBox2.Controls.Add(this.radLabel18);
            this.radGroupBox2.Controls.Add(this.radLabel10);
            this.radGroupBox2.Controls.Add(this.radLabel17);
            this.radGroupBox2.Controls.Add(this.tocustomercode);
            this.radGroupBox2.Controls.Add(this.radLabel16);
            this.radGroupBox2.Controls.Add(this.radLabel11);
            this.radGroupBox2.Controls.Add(this.fromrepairorderno);
            this.radGroupBox2.Controls.Add(this.radLabel12);
            this.radGroupBox2.Controls.Add(this.radLabel15);
            this.radGroupBox2.Controls.Add(this.radLabel13);
            this.radGroupBox2.Controls.Add(this.radLabel14);
            this.radGroupBox2.Controls.Add(this.openordersonly);
            this.radGroupBox2.Controls.Add(this.sortbystyleno);
            this.radGroupBox2.HeaderText = "";
            this.radGroupBox2.Location = new System.Drawing.Point(12, 163);
            this.radGroupBox2.Name = "radGroupBox2";
            this.radGroupBox2.Size = new System.Drawing.Size(462, 259);
            this.radGroupBox2.TabIndex = 3;
            // 
            // todate
            // 
            this.todate.CustomFormat = "\"\"";
            this.todate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.todate.Location = new System.Drawing.Point(136, 98);
            this.todate.Name = "todate";
            this.todate.Size = new System.Drawing.Size(173, 20);
            this.todate.TabIndex = 7;
            this.todate.TabStop = false;
            this.todate.ThemeName = "TelerikMetroBlue";
            this.todate.Value = new System.DateTime(((long)(0)));
            // 
            // fromdate
            // 
            this.fromdate.CustomFormat = "\"\"";
            this.fromdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.fromdate.Location = new System.Drawing.Point(136, 75);
            this.fromdate.Name = "fromdate";
            this.fromdate.Size = new System.Drawing.Size(173, 20);
            this.fromdate.TabIndex = 6;
            this.fromdate.TabStop = false;
            this.fromdate.ThemeName = "TelerikMetroBlue";
            this.fromdate.Value = new System.DateTime(((long)(0)));
            this.fromdate.Validating += new System.ComponentModel.CancelEventHandler(this.fromdate_Validating);
            // 
            // radLabel8
            // 
            this.radLabel8.Location = new System.Drawing.Point(18, 6);
            this.radLabel8.Name = "radLabel8";
            this.radLabel8.Size = new System.Drawing.Size(113, 18);
            this.radLabel8.TabIndex = 47;
            this.radLabel8.Text = "From Customer Code";
            // 
            // radLabel19
            // 
            this.radLabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel19.Location = new System.Drawing.Point(323, 171);
            this.radLabel19.Name = "radLabel19";
            this.radLabel19.Size = new System.Drawing.Size(108, 16);
            this.radLabel19.TabIndex = 61;
            this.radLabel19.Text = "Leave Blank For All";
            // 
            // fromcustomercode
            // 
            this.fromcustomercode.Location = new System.Drawing.Point(137, 6);
            this.fromcustomercode.Name = "fromcustomercode";
            this.fromcustomercode.Size = new System.Drawing.Size(173, 20);
            this.fromcustomercode.TabIndex = 4;
            this.fromcustomercode.TextChanged += new System.EventHandler(this.fromcustomercode_TextChanged);
            this.fromcustomercode.Validating += new System.ComponentModel.CancelEventHandler(this.fromcustomercode_Validating);
            // 
            // torepairorderno
            // 
            this.torepairorderno.Location = new System.Drawing.Point(137, 171);
            this.torepairorderno.Name = "torepairorderno";
            this.torepairorderno.Size = new System.Drawing.Size(173, 20);
            this.torepairorderno.TabIndex = 9;
            // 
            // radLabel9
            // 
            this.radLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel9.Location = new System.Drawing.Point(323, 8);
            this.radLabel9.Name = "radLabel9";
            this.radLabel9.Size = new System.Drawing.Size(108, 16);
            this.radLabel9.TabIndex = 48;
            this.radLabel9.Text = "Leave Blank For All";
            // 
            // radLabel18
            // 
            this.radLabel18.Location = new System.Drawing.Point(18, 173);
            this.radLabel18.Name = "radLabel18";
            this.radLabel18.Size = new System.Drawing.Size(104, 18);
            this.radLabel18.TabIndex = 60;
            this.radLabel18.Text = "To Repair Order No";
            // 
            // radLabel10
            // 
            this.radLabel10.Location = new System.Drawing.Point(18, 30);
            this.radLabel10.Name = "radLabel10";
            this.radLabel10.Size = new System.Drawing.Size(100, 18);
            this.radLabel10.TabIndex = 49;
            this.radLabel10.Text = "To Customer Code";
            // 
            // radLabel17
            // 
            this.radLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel17.Location = new System.Drawing.Point(323, 147);
            this.radLabel17.Name = "radLabel17";
            this.radLabel17.Size = new System.Drawing.Size(108, 16);
            this.radLabel17.TabIndex = 59;
            this.radLabel17.Text = "Leave Blank For All";
            // 
            // tocustomercode
            // 
            this.tocustomercode.Location = new System.Drawing.Point(137, 28);
            this.tocustomercode.Name = "tocustomercode";
            this.tocustomercode.Size = new System.Drawing.Size(173, 20);
            this.tocustomercode.TabIndex = 5;
            // 
            // radLabel16
            // 
            this.radLabel16.Location = new System.Drawing.Point(18, 149);
            this.radLabel16.Name = "radLabel16";
            this.radLabel16.Size = new System.Drawing.Size(117, 18);
            this.radLabel16.TabIndex = 57;
            this.radLabel16.Text = "From Repair Order No";
            // 
            // radLabel11
            // 
            this.radLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel11.Location = new System.Drawing.Point(323, 28);
            this.radLabel11.Name = "radLabel11";
            this.radLabel11.Size = new System.Drawing.Size(108, 16);
            this.radLabel11.TabIndex = 51;
            this.radLabel11.Text = "Leave Blank For All";
            // 
            // fromrepairorderno
            // 
            this.fromrepairorderno.Location = new System.Drawing.Point(137, 147);
            this.fromrepairorderno.Name = "fromrepairorderno";
            this.fromrepairorderno.Size = new System.Drawing.Size(173, 20);
            this.fromrepairorderno.TabIndex = 8;
            this.fromrepairorderno.Validating += new System.ComponentModel.CancelEventHandler(this.fromrepairorderno_Validating);
            // 
            // radLabel12
            // 
            this.radLabel12.Location = new System.Drawing.Point(19, 75);
            this.radLabel12.Name = "radLabel12";
            this.radLabel12.Size = new System.Drawing.Size(59, 18);
            this.radLabel12.TabIndex = 52;
            this.radLabel12.Text = "From Date";
            // 
            // radLabel15
            // 
            this.radLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel15.Location = new System.Drawing.Point(324, 100);
            this.radLabel15.Name = "radLabel15";
            this.radLabel15.Size = new System.Drawing.Size(108, 16);
            this.radLabel15.TabIndex = 56;
            this.radLabel15.Text = "Leave Blank For All";
            // 
            // radLabel13
            // 
            this.radLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel13.Location = new System.Drawing.Point(323, 73);
            this.radLabel13.Name = "radLabel13";
            this.radLabel13.Size = new System.Drawing.Size(108, 16);
            this.radLabel13.TabIndex = 53;
            this.radLabel13.Text = "Leave Blank For All";
            // 
            // radLabel14
            // 
            this.radLabel14.Location = new System.Drawing.Point(19, 99);
            this.radLabel14.Name = "radLabel14";
            this.radLabel14.Size = new System.Drawing.Size(45, 18);
            this.radLabel14.TabIndex = 54;
            this.radLabel14.Text = "To Date";
            // 
            // openordersonly
            // 
            this.openordersonly.Location = new System.Drawing.Point(21, 232);
            this.openordersonly.Name = "openordersonly";
            this.openordersonly.Size = new System.Drawing.Size(111, 18);
            this.openordersonly.TabIndex = 11;
            this.openordersonly.Text = "Open Orders Only";
            // 
            // sortbystyleno
            // 
            this.sortbystyleno.Location = new System.Drawing.Point(21, 208);
            this.sortbystyleno.Name = "sortbystyleno";
            this.sortbystyleno.Size = new System.Drawing.Size(103, 18);
            this.sortbystyleno.TabIndex = 10;
            this.sortbystyleno.Text = "Sort By Style No.";
            // 
            // radLabel2
            // 
            this.radLabel2.AutoSize = false;
            this.radLabel2.BackColor = System.Drawing.Color.Green;
            this.radLabel2.BorderVisible = true;
            this.radLabel2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel2.ForeColor = System.Drawing.Color.White;
            this.radLabel2.Location = new System.Drawing.Point(12, 145);
            this.radLabel2.Name = "radLabel2";
            this.radLabel2.Size = new System.Drawing.Size(462, 18);
            this.radLabel2.TabIndex = 2;
            this.radLabel2.Text = "Print List Of Repair Orders";
            this.radLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // radGroupBox1
            // 
            this.radGroupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.Grouping;
            this.radGroupBox1.Controls.Add(this.radLabel6);
            this.radGroupBox1.Controls.Add(this.radLabel21);
            this.radGroupBox1.Controls.Add(this.customerrepairnumber);
            this.radGroupBox1.Controls.Add(this.radLabel20);
            this.radGroupBox1.Controls.Add(this.radLabel3);
            this.radGroupBox1.Controls.Add(this.repairnumber);
            this.radGroupBox1.Controls.Add(this.lblLeaveBlank1);
            this.radGroupBox1.Controls.Add(this.radLabel4);
            this.radGroupBox1.Controls.Add(this.customercode);
            this.radGroupBox1.Controls.Add(this.radLabel5);
            this.radGroupBox1.HeaderText = "";
            this.radGroupBox1.Location = new System.Drawing.Point(12, 30);
            this.radGroupBox1.Name = "radGroupBox1";
            this.radGroupBox1.Size = new System.Drawing.Size(462, 109);
            this.radGroupBox1.TabIndex = 1;
            // 
            // radLabel6
            // 
            this.radLabel6.ForeColor = System.Drawing.Color.Red;
            this.radLabel6.Location = new System.Drawing.Point(209, 34);
            this.radLabel6.Name = "radLabel6";
            this.radLabel6.Size = new System.Drawing.Size(21, 18);
            this.radLabel6.TabIndex = 25;
            this.radLabel6.Text = "OR";
            // 
            // radLabel21
            // 
            this.radLabel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel21.Location = new System.Drawing.Point(325, 80);
            this.radLabel21.Name = "radLabel21";
            this.radLabel21.Size = new System.Drawing.Size(108, 16);
            this.radLabel21.TabIndex = 24;
            this.radLabel21.Text = "Leave Blank For All";
            // 
            // customerrepairnumber
            // 
            this.customerrepairnumber.Location = new System.Drawing.Point(139, 80);
            this.customerrepairnumber.Name = "customerrepairnumber";
            this.customerrepairnumber.Size = new System.Drawing.Size(173, 20);
            this.customerrepairnumber.TabIndex = 3;
            // 
            // radLabel20
            // 
            this.radLabel20.Location = new System.Drawing.Point(22, 82);
            this.radLabel20.Name = "radLabel20";
            this.radLabel20.Size = new System.Drawing.Size(108, 18);
            this.radLabel20.TabIndex = 22;
            this.radLabel20.Text = "Customer Repair No";
            // 
            // radLabel3
            // 
            this.radLabel3.Location = new System.Drawing.Point(21, 6);
            this.radLabel3.Name = "radLabel3";
            this.radLabel3.Size = new System.Drawing.Size(56, 18);
            this.radLabel3.TabIndex = 16;
            this.radLabel3.Text = "Repair No";
            // 
            // repairnumber
            // 
            this.repairnumber.Location = new System.Drawing.Point(140, 6);
            this.repairnumber.MaxLength = 6;
            this.repairnumber.Name = "repairnumber";
            this.repairnumber.Size = new System.Drawing.Size(173, 20);
            this.repairnumber.TabIndex = 1;
            // 
            // lblLeaveBlank1
            // 
            this.lblLeaveBlank1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLeaveBlank1.Location = new System.Drawing.Point(326, 9);
            this.lblLeaveBlank1.Name = "lblLeaveBlank1";
            this.lblLeaveBlank1.Size = new System.Drawing.Size(108, 16);
            this.lblLeaveBlank1.TabIndex = 18;
            this.lblLeaveBlank1.Text = "Leave Blank For All";
            // 
            // radLabel4
            // 
            this.radLabel4.Location = new System.Drawing.Point(21, 58);
            this.radLabel4.Name = "radLabel4";
            this.radLabel4.Size = new System.Drawing.Size(84, 18);
            this.radLabel4.TabIndex = 19;
            this.radLabel4.Text = "Customer Code";
            // 
            // customercode
            // 
            this.customercode.Location = new System.Drawing.Point(139, 58);
            this.customercode.Name = "customercode";
            this.customercode.Size = new System.Drawing.Size(173, 20);
            this.customercode.TabIndex = 2;
            // 
            // radLabel5
            // 
            this.radLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radLabel5.Location = new System.Drawing.Point(325, 58);
            this.radLabel5.Name = "radLabel5";
            this.radLabel5.Size = new System.Drawing.Size(108, 16);
            this.radLabel5.TabIndex = 21;
            this.radLabel5.Text = "Leave Blank For All";
            // 
            // radLabel1
            // 
            this.radLabel1.AutoSize = false;
            this.radLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.radLabel1.BorderVisible = true;
            this.radLabel1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold);
            this.radLabel1.ForeColor = System.Drawing.Color.White;
            this.radLabel1.Location = new System.Drawing.Point(12, 12);
            this.radLabel1.Name = "radLabel1";
            this.radLabel1.Size = new System.Drawing.Size(462, 18);
            this.radLabel1.TabIndex = 0;
            this.radLabel1.Text = "Print One Repair Order Details";
            this.radLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmRepairOrdersReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 480);
            this.Controls.Add(this.radButton2);
            this.Controls.Add(this.radButton1);
            this.Controls.Add(this.radGroupBox3);
            this.Controls.Add(this.radGroupBox2);
            this.Controls.Add(this.radLabel2);
            this.Controls.Add(this.radGroupBox1);
            this.Controls.Add(this.radLabel1);
            this.Name = "frmRepairOrdersReport";
            // 
            // 
            // 
            this.RootElement.ApplyShapeToControl = true;
            this.Text = "frmRepairOrdersReport";
            ((System.ComponentModel.ISupportInitialize)(this.radButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox3)).EndInit();
            this.radGroupBox3.ResumeLayout(false);
            this.radGroupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.print)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.email)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.preview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox2)).EndInit();
            this.radGroupBox2.ResumeLayout(false);
            this.radGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.todate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fromdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fromcustomercode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.torepairorderno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tocustomercode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fromrepairorderno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.openordersonly)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sortbystyleno)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radGroupBox1)).EndInit();
            this.radGroupBox1.ResumeLayout(false);
            this.radGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerrepairnumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repairnumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lblLeaveBlank1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customercode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Telerik.WinControls.UI.RadButton radButton2;
        private Telerik.WinControls.UI.RadButton radButton1;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox3;
        private Telerik.WinControls.UI.RadRadioButton print;
        private Telerik.WinControls.UI.RadRadioButton email;
        private Telerik.WinControls.UI.RadRadioButton preview;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox2;
        private Telerik.WinControls.UI.RadDateTimePicker todate;
        private Telerik.WinControls.UI.RadDateTimePicker fromdate;
        private Telerik.WinControls.UI.RadLabel radLabel8;
        private Telerik.WinControls.UI.RadLabel radLabel19;
        private Telerik.WinControls.UI.RadTextBox fromcustomercode;
        private Telerik.WinControls.UI.RadTextBox torepairorderno;
        private Telerik.WinControls.UI.RadLabel radLabel9;
        private Telerik.WinControls.UI.RadLabel radLabel18;
        private Telerik.WinControls.UI.RadLabel radLabel10;
        private Telerik.WinControls.UI.RadLabel radLabel17;
        private Telerik.WinControls.UI.RadTextBox tocustomercode;
        private Telerik.WinControls.UI.RadLabel radLabel16;
        private Telerik.WinControls.UI.RadLabel radLabel11;
        private Telerik.WinControls.UI.RadTextBox fromrepairorderno;
        private Telerik.WinControls.UI.RadLabel radLabel12;
        private Telerik.WinControls.UI.RadLabel radLabel15;
        private Telerik.WinControls.UI.RadLabel radLabel13;
        private Telerik.WinControls.UI.RadLabel radLabel14;
        private Telerik.WinControls.UI.RadCheckBox openordersonly;
        private Telerik.WinControls.UI.RadCheckBox sortbystyleno;
        private Telerik.WinControls.UI.RadLabel radLabel2;
        private Telerik.WinControls.UI.RadGroupBox radGroupBox1;
        private Telerik.WinControls.UI.RadLabel radLabel6;
        private Telerik.WinControls.UI.RadLabel radLabel21;
        private Telerik.WinControls.UI.RadTextBox customerrepairnumber;
        private Telerik.WinControls.UI.RadLabel radLabel20;
        private Telerik.WinControls.UI.RadLabel radLabel3;
        private Telerik.WinControls.UI.RadTextBox repairnumber;
        private Telerik.WinControls.UI.RadLabel lblLeaveBlank1;
        private Telerik.WinControls.UI.RadLabel radLabel4;
        private Telerik.WinControls.UI.RadTextBox customercode;
        private Telerik.WinControls.UI.RadLabel radLabel5;
        private Telerik.WinControls.UI.RadLabel radLabel1;
    }
}
